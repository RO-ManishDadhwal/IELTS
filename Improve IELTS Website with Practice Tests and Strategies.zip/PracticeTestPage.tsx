import React from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { ChevronRight } from 'lucide-react';

interface PracticeTestProps {
  section: 'reading' | 'writing' | 'listening' | 'speaking';
}

const PracticeTestPage: React.FC<PracticeTestProps> = ({ section }) => {
  const sectionColors = {
    reading: 'text-blue-700',
    writing: 'text-green-700',
    listening: 'text-purple-700',
    speaking: 'text-orange-700'
  };

  const sectionBgColors = {
    reading: 'bg-blue-50',
    writing: 'bg-green-50',
    listening: 'bg-purple-50',
    speaking: 'bg-orange-50'
  };

  const sectionTitle = section.charAt(0).toUpperCase() + section.slice(1);
  
  // Mock data for practice tests
  const practiceTests = Array.from({ length: 50 }, (_, i) => ({
    id: `${section}-test-${i + 1}`,
    title: `Cambridge IELTS ${sectionTitle} Test ${i + 1}`,
    description: `Complete ${sectionTitle.toLowerCase()} practice test with authentic Cambridge materials.`,
    difficulty: i < 15 ? 'Easy' : i < 35 ? 'Medium' : 'Hard',
    timeRequired: section === 'reading' || section === 'listening' ? '60 minutes' : 
                 section === 'writing' ? '60 minutes' : '11-14 minutes',
    questions: section === 'reading' || section === 'listening' ? 40 : 
              section === 'writing' ? 2 : 3,
    url: `/practice-tests/${section}/test-${i + 1}`
  }));

  const difficultyBadgeColor = (difficulty: string) => {
    switch(difficulty) {
      case 'Easy': return 'bg-green-100 text-green-800';
      case 'Medium': return 'bg-yellow-100 text-yellow-800';
      case 'Hard': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="text-center mb-12">
        <h1 className={`text-4xl font-bold mb-4 ${sectionColors[section]}`}>
          IELTS {sectionTitle} Practice Tests
        </h1>
        <p className="text-xl text-gray-600 max-w-3xl mx-auto">
          50 authentic Cambridge practice tests to help you prepare for the IELTS {sectionTitle} section.
          Target score: {
            section === 'reading' ? 'Band 8' :
            section === 'writing' ? 'Band 7-7.5' :
            section === 'listening' ? 'Band 8.5' : 'Band 7'
          }
        </p>
      </div>

      <div className={`${sectionBgColors[section]} p-6 rounded-lg mb-12`}>
        <h2 className="text-2xl font-bold mb-4">About the IELTS {sectionTitle} Test</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white p-4 rounded-lg shadow-sm">
            <h3 className="font-bold mb-2">Format</h3>
            <p>{
              section === 'reading' ? 'Three passages of increasing difficulty with 40 questions to be completed in 60 minutes.' :
              section === 'writing' ? 'Two tasks: Task 1 (graph/diagram description) and Task 2 (essay) to be completed in 60 minutes.' :
              section === 'listening' ? 'Four sections with 40 questions to be completed in 30 minutes, plus 10 minutes transfer time.' :
              'Three parts: Introduction and interview, individual long turn, and two-way discussion. 11-14 minutes total.'
            }</p>
          </div>
          <div className="bg-white p-4 rounded-lg shadow-sm">
            <h3 className="font-bold mb-2">Question Types</h3>
            <p>{
              section === 'reading' ? 'Multiple choice, identifying information, matching headings, sentence completion, and more.' :
              section === 'writing' ? 'Task 1: Chart/graph description, process diagram, map description. Task 2: Opinion, discussion, problem/solution essays.' :
              section === 'listening' ? 'Multiple choice, matching, map labeling, form completion, sentence completion, short answers.' :
              'Part 1: Familiar topics. Part 2: Individual long turn with cue card. Part 3: Abstract discussion related to Part 2 topic.'
            }</p>
          </div>
          <div className="bg-white p-4 rounded-lg shadow-sm">
            <h3 className="font-bold mb-2">Scoring</h3>
            <p>{
              section === 'reading' ? 'Each correct answer is worth 1 mark. Scores out of 40 are converted to the IELTS 9-band scale.' :
              section === 'writing' ? 'Assessed on: Task Achievement, Coherence and Cohesion, Lexical Resource, Grammatical Range and Accuracy.' :
              section === 'listening' ? 'Each correct answer is worth 1 mark. Scores out of 40 are converted to the IELTS 9-band scale.' :
              'Assessed on: Fluency and Coherence, Lexical Resource, Grammatical Range and Accuracy, Pronunciation.'
            }</p>
          </div>
        </div>
      </div>

      <div className="mb-12">
        <h2 className="text-2xl font-bold mb-6">Practice Tests</h2>
        
        <Tabs defaultValue="all">
          <TabsList className="mb-6">
            <TabsTrigger value="all">All Tests</TabsTrigger>
            <TabsTrigger value="easy">Easy</TabsTrigger>
            <TabsTrigger value="medium">Medium</TabsTrigger>
            <TabsTrigger value="hard">Hard</TabsTrigger>
          </TabsList>
          
          {['all', 'easy', 'medium', 'hard'].map(difficulty => (
            <TabsContent key={difficulty} value={difficulty} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {practiceTests
                .filter(test => difficulty === 'all' || test.difficulty.toLowerCase() === difficulty)
                .map(test => (
                  <Card key={test.id} className="hover:shadow-md transition-shadow">
                    <CardHeader className="pb-2">
                      <div className="flex justify-between items-start">
                        <CardTitle className="text-xl">{test.title}</CardTitle>
                        <Badge className={difficultyBadgeColor(test.difficulty)}>
                          {test.difficulty}
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <CardDescription className="text-base mb-4">{test.description}</CardDescription>
                      <div className="flex justify-between text-sm text-gray-500">
                        <div>Time: {test.timeRequired}</div>
                        <div>Questions: {test.questions}</div>
                      </div>
                    </CardContent>
                    <CardFooter>
                      <Button className={`w-full ${sectionColors[section]} bg-white hover:bg-gray-50`} variant="outline" asChild>
                        <a href={test.url}>
                          Start Test <ChevronRight className="ml-2 h-4 w-4" />
                        </a>
                      </Button>
                    </CardFooter>
                  </Card>
                ))}
            </TabsContent>
          ))}
        </Tabs>
      </div>

      <div className="bg-gray-50 p-6 rounded-lg">
        <h2 className="text-2xl font-bold mb-4">Tips for the {sectionTitle} Test</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h3 className="font-bold text-lg mb-2">Preparation Strategies</h3>
            <ul className="list-disc pl-5 space-y-2">
              {section === 'reading' ? (
                <>
                  <li>Practice skimming and scanning techniques</li>
                  <li>Improve your vocabulary, especially academic words</li>
                  <li>Practice time management - 20 minutes per passage</li>
                  <li>Learn to identify different question types quickly</li>
                  <li>Practice reading a variety of academic texts</li>
                </>
              ) : section === 'writing' ? (
                <>
                  <li>Study the assessment criteria thoroughly</li>
                  <li>Practice analyzing different chart types for Task 1</li>
                  <li>Learn paragraph structures for different essay types</li>
                  <li>Build a bank of complex grammatical structures</li>
                  <li>Practice planning your response in 3-5 minutes</li>
                </>
              ) : section === 'listening' ? (
                <>
                  <li>Practice note-taking techniques</li>
                  <li>Improve your ability to predict answers</li>
                  <li>Listen to a variety of English accents</li>
                  <li>Practice with background noise to build concentration</li>
                  <li>Learn to follow instructions carefully</li>
                </>
              ) : (
                <>
                  <li>Record yourself speaking and analyze your performance</li>
                  <li>Practice extending your answers in Part 1</li>
                  <li>Learn to organize your thoughts quickly for Part 2</li>
                  <li>Develop your ability to discuss abstract topics for Part 3</li>
                  <li>Work on pronunciation and intonation</li>
                </>
              )}
            </ul>
          </div>
          <div>
            <h3 className="font-bold text-lg mb-2">Common Mistakes to Avoid</h3>
            <ul className="list-disc pl-5 space-y-2">
              {section === 'reading' ? (
                <>
                  <li>Spending too long on difficult questions</li>
                  <li>Not reading the instructions carefully</li>
                  <li>Adding information not in the passage</li>
                  <li>Misunderstanding the difference between True/False/Not Given</li>
                  <li>Not checking spelling in your answers</li>
                </>
              ) : section === 'writing' ? (
                <>
                  <li>Not addressing all parts of the task</li>
                  <li>Writing too generally without specific examples</li>
                  <li>Poor paragraph organization</li>
                  <li>Overusing simple sentence structures</li>
                  <li>Not leaving time to review your work</li>
                </>
              ) : section === 'listening' ? (
                <>
                  <li>Getting stuck on missed answers</li>
                  <li>Not reading ahead to prepare for the next section</li>
                  <li>Spelling errors in answers</li>
                  <li>Missing plural forms or third person 's'</li>
                  <li>Not following word count limits</li>
                </>
              ) : (
                <>
                  <li>Giving very short answers in Part 1</li>
                  <li>Not using the preparation time effectively in Part 2</li>
                  <li>Using memorized responses that sound unnatural</li>
                  <li>Limited vocabulary and repetitive language</li>
                  <li>Speaking too fast or too slowly</li>
                </>
              )}
            </ul>
          </div>
        </div>
      </div>

      <div className="mt-12 text-center">
        <h2 className="text-2xl font-bold mb-4">Ready to Improve Your {sectionTitle} Skills?</h2>
        <p className="text-lg text-gray-600 mb-6">
          Check out our comprehensive strategy guide for achieving {
            section === 'reading' ? 'Band 8' :
            section === 'writing' ? 'Band 7-7.5' :
            section === 'listening' ? 'Band 8.5' : 'Band 7'
          } in IELTS {sectionTitle}.
        </p>
        <Button className={`${sectionColors[section]} bg-white hover:bg-gray-50`} variant="outline" size="lg" asChild>
          <a href={`/strategy-guides/${section}`}>
            View {sectionTitle} Strategy Guide
          </a>
        </Button>
      </div>
    </div>
  );
};

export default PracticeTestPage;
