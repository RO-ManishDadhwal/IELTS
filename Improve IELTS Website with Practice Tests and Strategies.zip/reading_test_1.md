# Sample IELTS Reading Practice Test 1 (Band 7+)

## READING PASSAGE 1

### THE HISTORY OF CHOCOLATE

Chocolate is made from the fruit of cacao trees, which are native to Central and South America. The fruits are called pods and each pod contains around 40 cacao beans. The beans are dried and roasted to create cocoa beans.

It's unclear precisely when cacao came on the scene or who invented it. According to Hayes Lavis, cultural arts curator for the Smithsonian's National Museum of the American Indian, ancient Olmec pots and vessels from around 1500 B.C. were discovered with traces of theobromine, a stimulant compound found in chocolate and tea. It's thought that the Olmecs used cacao to create a ceremonial drink. However, since they kept no written history, we'll never know for sure.

The Olmecs lived in the lowlands of south-central Mexico. It's thought that they passed their cacao knowledge on to the Central American Mayans, who not only consumed chocolate but also revered it. The Mayan people created a god of cacao and reserved chocolate for rulers, warriors, priests and nobles at sacred ceremonies.

The Aztecs took chocolate admiration to another level. They believed cacao was given to them by their gods. Like the Mayans, they enjoyed the caffeinated kick of hot or cold, spiced chocolate beverages in ornate containers, but they also used cacao beans as currency to buy food and other goods. In Aztec culture, cacao beans were considered more valuable than gold.

Aztec chocolate was mostly an upper-class extravagance, although the lower classes enjoyed it at weddings or other celebrations. The chocolate drink of preference at the time was a cold, unsweetened mixture of cacao beans, water, chili peppers, cornmeal and other ingredients poured back and forth between two containers to create a frothy head. The resulting drink was known as 'xocolatl', meaning 'bitter water'.

Chocolate arrived in Europe in the 1500s, brought by Spanish conquistadors who had seen its value among the Aztecs. King Charles V of Spain was served xocolatl during his visit to Hernán Cortés in 1527, and chocolate soon spread throughout Europe's royal courts. The Spanish adapted the beverage by removing the chili pepper, adding sugar and cinnamon, and serving it hot rather than cold.

For several hundred years, chocolate remained a Spanish secret, but when the daughter of Spanish King Philip III married French King Louis XIII in 1615, she brought her love of chocolate with her to France. The popularity of chocolate quickly spread to other European courts, and aristocrats consumed it as a magic elixir with health benefits.

In the late 1700s, chocolate made its way to the United States. Chocolate was so valued during the American Revolutionary War that it was included in soldiers' rations and used in lieu of wages. After the war, the first American chocolate factory was established in 1780 in Boston.

During the Industrial Revolution, chocolate became available to the masses. The invention of the steam engine made it possible to grind cacao beans faster and cheaper than ever before. In 1828, Dutch chemist Coenraad Johannes van Houten invented the cacao press, which separated cocoa butter from roasted cacao beans to create cocoa powder, the basis of all chocolate products.

The creation of solid chocolate became possible when, in 1847, British chocolatier Joseph Fry discovered a way to mix cocoa powder, sugar and cocoa to create a paste that could be molded into a chocolate bar. Milk chocolate hit the market a few decades later, pioneered by Swiss chocolatier Daniel Peter, who combined chocolate with powdered milk, which had been invented by Swiss chemist Henri Nestlé.

Today, the chocolate industry is a multi-billion-dollar industry, and the average American consumes roughly 4.5 kg of chocolate each year. The process for making chocolate has changed little over the years, but modern innovations have made it easier to produce on a mass scale.

### Questions 1-6
Complete the notes below.
Choose NO MORE THAN TWO WORDS from the passage for each answer.

Early History of Chocolate
- Traces of theobromine found in Olmec vessels from approximately (1) ____________
- Olmecs likely used cacao to make a (2) ____________
- Mayans created a (3) ____________ of cacao
- Aztecs believed cacao was a gift from their (4) ____________
- Aztecs used cacao beans as (5) ____________
- The Aztec chocolate drink was called (6) ____________

### Questions 7-13
Do the following statements agree with the information given in Reading Passage 1?
Write
TRUE if the statement agrees with the information
FALSE if the statement contradicts the information
NOT GIVEN if there is no information on this

7. The Olmecs had a written history documenting their use of cacao.
8. The Mayans allowed all social classes to consume chocolate.
9. The Aztecs typically drank their chocolate hot with sugar.
10. Spanish royalty was introduced to chocolate in the early 16th century.
11. Chocolate remained exclusively Spanish for about a century.
12. During the American Revolutionary War, chocolate was sometimes used instead of money.
13. The invention of the cacao press made chocolate more affordable for average people.

## READING PASSAGE 2

### THE FLYNN EFFECT

For the past century, average IQ scores around the world have been steadily increasing at a rate of approximately three points per decade. This phenomenon, known as the 'Flynn Effect' after political scientist James R. Flynn who documented it extensively, represents one of the most intriguing and robust findings in intelligence research. The effect has been observed in more than 30 countries, including those in North America, Europe, Asia, and Australasia, suggesting a global pattern rather than one limited to specific cultures or regions.

The magnitude of these gains is substantial. In some countries, average scores have risen by more than 20 points (more than one standard deviation) in a single generation. To put this in perspective, if we were to compare the average person from 1910 with the average person from 2010 using the same IQ test, the modern individual would score approximately 30 points higher. Given that the standard deviation for IQ scores is 15 points, this represents a massive cognitive gap between generations.

What makes the Flynn Effect particularly fascinating is that these gains have not occurred evenly across all types of cognitive abilities. The largest increases have been observed in tests measuring abstract reasoning, pattern recognition, and spatial visualization—cognitive skills that reflect our ability to classify, understand abstract concepts, and solve novel problems. By contrast, gains in vocabulary, arithmetic, and general knowledge have been more modest.

Several theories have been proposed to explain this remarkable trend. One compelling explanation focuses on environmental factors. Over the past century, significant improvements in nutrition, education, healthcare, and overall living standards have created conditions more conducive to cognitive development. Children today are better nourished, receive more formal education, and are exposed to more cognitively stimulating environments than previous generations.

The changing nature of modern life may also play a role. Today's world is visually complex, technologically sophisticated, and information-rich compared to the environment of a century ago. We are constantly bombarded with symbols, icons, advertisements, and digital interfaces that require rapid processing of abstract visual information. Modern occupations increasingly demand analytical thinking rather than manual labor, and leisure activities often involve complex problem-solving (as in video games) or abstract narrative structures (as in film and television). These environmental changes may have helped cultivate precisely the cognitive skills that show the largest gains.

Another theory points to the increasing complexity of families. Smaller family sizes, more educated parents, and more cognitively demanding parenting styles may contribute to enhanced cognitive development. Parents today are more likely to engage children in conversation, explain the reasons behind rules, and encourage educational activities than in previous generations.

Some researchers have suggested that the Flynn Effect may be partly explained by increasing familiarity with test-taking itself. As society has become more test-oriented, people have become more comfortable with the format and expectations of standardized tests. However, this explanation cannot account for the specific pattern of gains observed or their magnitude.

Interestingly, there is evidence that the Flynn Effect may be slowing or even reversing in some developed countries. Recent studies from Norway, Denmark, Finland, and France have reported small declines in average IQ scores among those born after the mid-1970s. This has led some researchers to suggest that we may have reached the upper limits of environmental contributions to intelligence, or that new environmental factors (such as changes in education systems or digital technology usage) may be having unanticipated negative effects on certain cognitive skills.

The implications of the Flynn Effect extend beyond academic interest. If IQ scores can change so dramatically in response to environmental factors, this challenges the notion that intelligence is fixed and immutable. It suggests that cognitive abilities are, to a significant degree, malleable and responsive to environmental conditions. This has profound implications for education, social policy, and our understanding of human potential.

The Flynn Effect also complicates historical comparisons of intelligence. If each generation performs better on IQ tests than the previous one, then using the same norms across different time periods would be misleading. This is why IQ tests are periodically re-normed to maintain an average score of 100 for each generation.

Perhaps most importantly, the Flynn Effect reminds us that human cognitive capabilities are not static but evolve in response to changing environmental demands. As our world continues to transform through technological innovation and cultural change, we can expect our cognitive abilities to adapt accordingly. The human mind, it seems, is remarkably responsive to the challenges and opportunities presented by its environment.

### Questions 14-19
Choose the correct letter, A, B, C, or D.

14. According to the passage, the Flynn Effect refers to
    A. an increase in IQ scores over time.
    B. a decrease in IQ scores in developed countries.
    C. fluctuations in IQ scores across different cultures.
    D. the relationship between education and intelligence.

15. The increase in IQ scores over the past century is approximately
    A. 15 points in total.
    B. 3 points per year.
    C. 30 points in total.
    D. 3 points per decade.

16. According to the passage, which cognitive abilities have shown the largest increases?
    A. Vocabulary and general knowledge
    B. Abstract reasoning and pattern recognition
    C. Arithmetic and verbal reasoning
    D. Memory and processing speed

17. Which of the following is NOT mentioned as a possible explanation for the Flynn Effect?
    A. Improvements in nutrition and healthcare
    B. Genetic evolution of the human brain
    C. More visually complex environments
    D. Changes in parenting styles

18. Recent studies from some developed countries suggest that the Flynn Effect
    A. is accelerating rapidly.
    B. may be slowing or reversing.
    C. varies significantly by gender.
    D. only affects certain ethnic groups.

19. According to the passage, IQ tests are periodically re-normed because
    A. they become outdated and too easy.
    B. each generation performs better than the previous one.
    C. they contain culturally biased questions.
    D. testing conditions have improved over time.

### Questions 20-26
Complete the summary using the list of words, A-K, below.

The Flynn Effect describes the (20) ______ in average IQ scores observed worldwide over the past century. These gains have been most pronounced in tests measuring (21) ______ rather than factual knowledge. Several explanations have been proposed, including improvements in (22) ______, more stimulating environments, and changes in family structure. The effect suggests that intelligence is (23) ______ rather than fixed, which has important implications for education and social policy. However, recent evidence indicates the effect may be (24) ______ in some developed countries, possibly because we have reached the (25) ______ of environmental contributions to intelligence. The Flynn Effect necessitates periodic (26) ______ of IQ tests to maintain accurate measurements across generations.

A. decrease
B. abstract reasoning
C. technology
D. nutrition
E. limits
F. adjustment
G. increase
H. verbal ability
I. malleable
J. accelerating
K. immutable

## READING PASSAGE 3

### URBAN AGRICULTURE: GROWING CITIES

In recent years, urban agriculture has emerged as a powerful movement that is transforming our relationship with food and reshaping urban landscapes around the world. From rooftop gardens in New York City to vertical farms in Singapore, city dwellers are increasingly turning to local food production as a response to concerns about food security, environmental sustainability, and community resilience.

Urban agriculture encompasses a diverse range of practices, including community gardens, rooftop farms, indoor vertical farming, aquaponics systems, and even keeping livestock such as chickens or bees in urban settings. What unites these varied approaches is their location within or around urban areas and their integration into the local urban economic and ecological system.

The potential benefits of urban agriculture are numerous and far-reaching. Perhaps most obviously, urban farms can significantly increase access to fresh, nutritious food in areas that might otherwise be considered "food deserts"—neighborhoods where residents have limited access to affordable, healthy food options. By producing food locally, urban agriculture also reduces the need for long-distance transportation, thereby decreasing carbon emissions associated with the food system. The environmental benefits extend beyond reduced food miles; urban farms can help mitigate the urban heat island effect, improve air quality, increase biodiversity, and manage stormwater runoff.

From a social perspective, urban agriculture projects often serve as community hubs that bring together diverse groups of people around the shared activities of growing, preparing, and sometimes selling food. These spaces can foster social connections, build community resilience, and provide educational opportunities, particularly for children who may have limited understanding of where their food comes from. For some participants, urban farming also offers therapeutic benefits, providing a respite from the stresses of urban life and opportunities for physical activity and connection with nature.

The economic dimensions of urban agriculture are equally significant. Urban farms can create jobs and entrepreneurial opportunities in food production, processing, and distribution. They can also increase property values in surrounding areas and reduce municipal costs related to stormwater management and urban cooling. For individual households, growing food can lead to substantial savings on grocery bills.

Despite these potential benefits, urban agriculture faces numerous challenges. Land access is perhaps the most significant barrier, as urban real estate is typically expensive and subject to competing demands. Soil contamination is another common concern in urban environments, necessitating soil testing and sometimes remediation before food production can safely occur. Regulatory frameworks in many cities were not desi
(Content truncated due to size limit. Use line ranges to read in chunks)