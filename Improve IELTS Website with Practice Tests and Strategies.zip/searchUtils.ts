import { SearchResult } from '../components/SearchResults';

// This is a mock implementation of the search functionality
// In a real application, this would connect to a backend API or database
export async function searchIeltsContent(query: string): Promise<SearchResult[]> {
  // Simulate API call delay
  await new Promise(resolve => setTimeout(resolve, 800));
  
  const normalizedQuery = query.toLowerCase().trim();
  
  // Mock database of searchable content
  const mockDatabase: SearchResult[] = [
    // Reading section
    {
      id: 'reading-practice-1',
      title: 'Cambridge IELTS Reading Practice Test 1',
      type: 'practice',
      section: 'reading',
      excerpt: 'Complete practice test with passages on environmental conservation, urban planning, and cognitive development.',
      url: '/practice-tests/reading/test-1',
      bandScore: '8'
    },
    {
      id: 'reading-strategy',
      title: 'Reading Strategy Guide for Band 8',
      type: 'strategy',
      section: 'reading',
      excerpt: 'Comprehensive strategies for achieving Band 8 in IELTS Reading, including time management and advanced comprehension techniques.',
      url: '/strategy-guides/reading/band8',
      bandScore: '8'
    },
    {
      id: 'reading-multiple-choice',
      title: 'Multiple Choice Questions - Reading',
      type: 'example',
      section: 'reading',
      excerpt: 'Examples and strategies for approaching multiple choice questions in the IELTS Reading test.',
      url: '/question-examples/reading/multiple-choice',
    },
    
    // Writing section
    {
      id: 'writing-practice-1',
      title: 'Cambridge IELTS Writing Practice Test 1',
      type: 'practice',
      section: 'writing',
      excerpt: 'Complete practice test with Task 1 data visualization and Task 2 essay on education.',
      url: '/practice-tests/writing/test-1',
      bandScore: '7.5'
    },
    {
      id: 'writing-strategy',
      title: 'Writing Strategy Guide for Band 7-7.5',
      type: 'strategy',
      section: 'writing',
      excerpt: 'Detailed strategies for achieving Band 7-7.5 in IELTS Writing, covering both Task 1 and Task 2.',
      url: '/strategy-guides/writing/band7-7.5',
      bandScore: '7.5'
    },
    {
      id: 'writing-task1-example',
      title: 'Task 1 Chart Description Examples',
      type: 'example',
      section: 'writing',
      excerpt: 'Sample responses and analysis for IELTS Writing Task 1 chart and graph descriptions.',
      url: '/question-examples/writing/task1-chart',
    },
    
    // Listening section
    {
      id: 'listening-practice-1',
      title: 'Cambridge IELTS Listening Practice Test 1',
      type: 'practice',
      section: 'listening',
      excerpt: 'Complete practice test with all four sections, including conversations and academic lectures.',
      url: '/practice-tests/listening/test-1',
      bandScore: '8.5'
    },
    {
      id: 'listening-strategy',
      title: 'Listening Strategy Guide for Band 8.5',
      type: 'strategy',
      section: 'listening',
      excerpt: 'Advanced strategies for achieving Band 8.5 in IELTS Listening, including note-taking and prediction techniques.',
      url: '/strategy-guides/listening/band8.5',
      bandScore: '8.5'
    },
    {
      id: 'listening-form-completion',
      title: 'Form Completion Questions - Listening',
      type: 'example',
      section: 'listening',
      excerpt: 'Examples and strategies for form completion questions in the IELTS Listening test.',
      url: '/question-examples/listening/form-completion',
    },
    
    // Speaking section
    {
      id: 'speaking-practice-1',
      title: 'Cambridge IELTS Speaking Practice Test 1',
      type: 'practice',
      section: 'speaking',
      excerpt: 'Complete practice test with all three parts, including common topics and follow-up questions.',
      url: '/practice-tests/speaking/test-1',
      bandScore: '7'
    },
    {
      id: 'speaking-strategy',
      title: 'Speaking Strategy Guide for Band 7',
      type: 'strategy',
      section: 'speaking',
      excerpt: 'Effective strategies for achieving Band 7 in IELTS Speaking, with techniques for all three parts.',
      url: '/strategy-guides/speaking/band7',
      bandScore: '7'
    },
    {
      id: 'speaking-part2-examples',
      title: 'Part 2 Cue Card Examples - Speaking',
      type: 'example',
      section: 'speaking',
      excerpt: 'Sample responses and analysis for IELTS Speaking Part 2 cue card topics.',
      url: '/question-examples/speaking/part2-cue-cards',
    },
    
    // Grammar resources
    {
      id: 'grammar-tenses',
      title: 'English Tenses for IELTS',
      type: 'grammar',
      excerpt: 'Comprehensive guide to English tenses with examples and common errors to avoid in IELTS.',
      url: '/grammar/tenses',
    },
    {
      id: 'grammar-conditionals',
      title: 'Conditional Sentences in IELTS',
      type: 'grammar',
      excerpt: 'Explanation of conditional sentence types with examples relevant to IELTS Writing and Speaking.',
      url: '/grammar/conditionals',
    },
    {
      id: 'grammar-articles',
      title: 'Articles (a, an, the) in English',
      type: 'grammar',
      excerpt: 'Detailed guide to using articles correctly in English, with common mistakes made by IELTS candidates.',
      url: '/grammar/articles',
    },
    
    // Question types
    {
      id: 'question-matching-headings',
      title: 'Matching Headings Questions',
      type: 'question',
      section: 'reading',
      excerpt: 'Strategies and examples for matching headings questions in the IELTS Reading test.',
      url: '/question-types/reading/matching-headings',
    },
    {
      id: 'question-map-labeling',
      title: 'Map Labeling Questions',
      type: 'question',
      section: 'listening',
      excerpt: 'Techniques for approaching map labeling questions in the IELTS Listening test.',
      url: '/question-types/listening/map-labeling',
    },
    {
      id: 'question-advantage-disadvantage',
      title: 'Advantage/Disadvantage Essays',
      type: 'question',
      section: 'writing',
      excerpt: 'Structure and sample responses for advantage/disadvantage essay questions in IELTS Writing Task 2.',
      url: '/question-types/writing/advantage-disadvantage',
    },
  ];
  
  // Filter results based on search query
  if (!normalizedQuery) {
    return [];
  }
  
  return mockDatabase.filter(item => {
    return (
      item.title.toLowerCase().includes(normalizedQuery) ||
      item.excerpt.toLowerCase().includes(normalizedQuery) ||
      (item.section && item.section.toLowerCase().includes(normalizedQuery)) ||
      item.type.toLowerCase().includes(normalizedQuery) ||
      (item.bandScore && `band ${item.bandScore}`.includes(normalizedQuery))
    );
  });
}
