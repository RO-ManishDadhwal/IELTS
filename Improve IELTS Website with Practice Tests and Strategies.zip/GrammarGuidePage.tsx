import React from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { BookOpen, BookText, Pencil, CheckCircle2 } from 'lucide-react';

const GrammarGuidePage: React.FC = () => {
  return (
    <div className="container mx-auto px-4 py-12">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold mb-4 text-indigo-700">
          IELTS Grammar Guide
        </h1>
        <p className="text-xl text-gray-600 max-w-3xl mx-auto">
          Comprehensive grammar resources with common error corrections to help you improve your accuracy in all IELTS sections.
        </p>
      </div>

      <div className="bg-indigo-50 p-6 rounded-lg mb-12">
        <h2 className="text-2xl font-bold mb-4">Why Grammar Matters in IELTS</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white p-4 rounded-lg shadow-sm">
            <h3 className="font-bold mb-2">Writing Assessment</h3>
            <p>Grammatical Range and Accuracy accounts for 25% of your Writing score. Using a variety of complex structures with good control is essential for Band 7+.</p>
          </div>
          <div className="bg-white p-4 rounded-lg shadow-sm">
            <h3 className="font-bold mb-2">Speaking Assessment</h3>
            <p>Grammatical Range and Accuracy is one of the four criteria in Speaking. Consistent errors can limit your band score even if your ideas are good.</p>
          </div>
          <div className="bg-white p-4 rounded-lg shadow-sm">
            <h3 className="font-bold mb-2">Reading & Listening</h3>
            <p>Strong grammar knowledge helps you understand complex sentences and relationships between ideas, improving your comprehension in these sections.</p>
          </div>
        </div>
      </div>

      <Tabs defaultValue="tenses">
        <TabsList className="mb-6">
          <TabsTrigger value="tenses">Tenses</TabsTrigger>
          <TabsTrigger value="conditionals">Conditionals</TabsTrigger>
          <TabsTrigger value="articles">Articles</TabsTrigger>
          <TabsTrigger value="prepositions">Prepositions</TabsTrigger>
          <TabsTrigger value="modals">Modal Verbs</TabsTrigger>
          <TabsTrigger value="passives">Passive Voice</TabsTrigger>
        </TabsList>
        
        <TabsContent value="tenses">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BookOpen className="h-5 w-5 text-indigo-600" />
                English Tenses
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-bold mb-3">Present Simple</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <h4 className="font-semibold text-indigo-700 mb-2">Usage</h4>
                      <ul className="list-disc pl-5 space-y-1">
                        <li>Facts and general truths</li>
                        <li>Habits and routines</li>
                        <li>Scheduled events in the near future</li>
                        <li>Instructions and directions</li>
                      </ul>
                      
                      <h4 className="font-semibold text-indigo-700 mt-4 mb-2">Structure</h4>
                      <p><span className="font-medium">Positive:</span> Subject + V1 (+ s/es for third person singular)</p>
                      <p><span className="font-medium">Negative:</span> Subject + do/does + not + V1</p>
                      <p><span className="font-medium">Question:</span> Do/Does + subject + V1?</p>
                    </div>
                    
                    <div className="bg-gray-50 p-4 rounded-lg">
                      <h4 className="font-semibold text-indigo-700 mb-2">Examples</h4>
                      <ul className="space-y-2">
                        <li><span className="font-medium">Positive:</span> Water <span className="underline">boils</span> at 100°C. (fact)</li>
                        <li><span className="font-medium">Positive:</span> She <span className="underline">works</span> in a hospital. (habit)</li>
                        <li><span className="font-medium">Negative:</span> They <span className="underline">do not live</span> in London. (fact)</li>
                        <li><span className="font-medium">Question:</span> <span className="underline">Does</span> he <span className="underline">speak</span> English? (ability)</li>
                      </ul>
                      
                      <h4 className="font-semibold text-indigo-700 mt-4 mb-2">Common Errors</h4>
                      <div className="space-y-2">
                        <div className="flex items-start gap-2">
                          <div className="text-red-500 mt-1">✗</div>
                          <div>He <span className="line-through">work</span> in a bank. (missing -s)</div>
                        </div>
                        <div className="flex items-start gap-2">
                          <div className="text-green-600 mt-1">✓</div>
                          <div>He <span className="font-bold">works</span> in a bank.</div>
                        </div>
                        
                        <div className="flex items-start gap-2 mt-3">
                          <div className="text-red-500 mt-1">✗</div>
                          <div>She <span className="line-through">doesn't works</span> on Sundays. (double verb)</div>
                        </div>
                        <div className="flex items-start gap-2">
                          <div className="text-green-600 mt-1">✓</div>
                          <div>She <span className="font-bold">doesn't work</span> on Sundays.</div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div>
                  <h3 className="text-lg font-bold mb-3">Present Continuous</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <h4 className="font-semibold text-indigo-700 mb-2">Usage</h4>
                      <ul className="list-disc pl-5 space-y-1">
                        <li>Actions happening now</li>
                        <li>Temporary situations</li>
                        <li>Planned future arrangements</li>
                        <li>Trends and changing situations</li>
                      </ul>
                      
                      <h4 className="font-semibold text-indigo-700 mt-4 mb-2">Structure</h4>
                      <p><span className="font-medium">Positive:</span> Subject + am/is/are + V-ing</p>
                      <p><span className="font-medium">Negative:</span> Subject + am/is/are + not + V-ing</p>
                      <p><span className="font-medium">Question:</span> Am/Is/Are + subject + V-ing?</p>
                    </div>
                    
                    <div className="bg-gray-50 p-4 rounded-lg">
                      <h4 className="font-semibold text-indigo-700 mb-2">Examples</h4>
                      <ul className="space-y-2">
                        <li><span className="font-medium">Positive:</span> She <span className="underline">is studying</span> for her exam. (now)</li>
                        <li><span className="font-medium">Positive:</span> I <span className="underline">am staying</span> with friends until I find an apartment. (temporary)</li>
                        <li><span className="font-medium">Negative:</span> They <span className="underline">aren't working</span> today. (now)</li>
                        <li><span className="font-medium">Question:</span> <span className="underline">Are</span> you <span className="underline">coming</span> to the meeting? (arrangement)</li>
                      </ul>
                      
                      <h4 className="font-semibold text-indigo-700 mt-4 mb-2">Common Errors</h4>
                      <div className="space-y-2">
                        <div className="flex items-start gap-2">
                          <div className="text-red-500 mt-1">✗</div>
                          <div>I <span className="line-through">studying</span> English now. (missing auxiliary)</div>
                        </div>
                        <div className="flex items-start gap-2">
                          <div className="text-green-600 mt-1">✓</div>
                          <div>I <span className="font-bold">am studying</span> English now.</div>
                        </div>
                        
                        <div className="flex items-start gap-2 mt-3">
                          <div className="text-red-500 mt-1">✗</div>
                          <div>She <span className="line-through">is think</span> about changing jobs. (stative verb)</div>
                        </div>
                        <div className="flex items-start gap-2">
                          <div className="text-green-600 mt-1">✓</div>
                          <div>She <span className="font-bold">is thinking</span> about changing jobs.</div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="text-center pt-4">
                  <Button className="text-indigo-700 bg-white hover:bg-indigo-50" variant="outline" asChild>
                    <a href="/grammar/tenses">
                      View All Tenses
                    </a>
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="conditionals">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BookOpen className="h-5 w-5 text-indigo-600" />
                Conditional Sentences
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-bold mb-3">Zero Conditional</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <h4 className="font-semibold text-indigo-700 mb-2">Usage</h4>
                      <ul className="list-disc pl-5 space-y-1">
                        <li>Scientific facts</li>
                        <li>General truths</li>
                        <li>Habits and routines with predictable results</li>
                      </ul>
                      
                      <h4 className="font-semibold text-indigo-700 mt-4 mb-2">Structure</h4>
                      <p>If + present simple, present simple</p>
                      <p>When + present simple, present simple</p>
                    </div>
                    
                    <div className="bg-gray-50 p-4 rounded-lg">
                      <h4 className="font-semibold text-indigo-700 mb-2">Examples</h4>
                      <ul className="space-y-2">
                        <li>If you <span className="underline">heat</span> water to 100°C, it <span className="underline">boils</span>.</li>
                        <li>If it <span className="underline">rains</span>, the ground <span className="underline">gets</span> wet.</li>
                        <li>When I <span className="underline">feel</span> tired, I <span className="underline">drink</span> coffee.</li>
                      </ul>
                      
                      <h4 className="font-semibold text-indigo-700 mt-4 mb-2">IELTS Application</h4>
                      <p>Use zero conditionals in Writing Task 2 when discussing scientific processes or general principles:</p>
                      <p className="italic">"If governments <span className="underline">invest</span> in public transportation, pollution levels <span className="underline">decrease</span>."</p>
                    </div>
                  </div>
                </div>
                
                <div>
                  <h3 className="text-lg font-bold mb-3">First Conditional</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <h4 className="font-semibold text-indigo-700 mb-2">Usage</h4>
                      <ul className="list-disc pl-5 space-y-1">
                        <li>Real or possible situations in the future</li>
                        <li>Likely outcomes</li>
                        <li>Warnings and promises</li>
                      </ul>
                      
                      <h4 className="font-semibold text-indigo-700 mt-4 mb-2">Structure</h4>
                      <p>If + present simple, will + infinitive</p>
                      <p>Will + infinitive + if + present simple</p>
                    </div>
                    
                    <div className="bg-gray-50 p-4 rounded-lg">
                      <h4 className="font-semibold text-indigo-700 mb-2">Examples</h4>
                      <ul className="space-y-2">
                        <li>If it <span className="underline">rains</span> tomorrow, we <span className="underline">will stay</span> at home.</li>
                        <li>I <span className="underline">will help</span> you if you <span className="underline">need</span> assistance.</li>
                        <li>If you <span className="underline">don't study</span>, you <span className="underline">won't pass</span> the exam.</li>
                      </ul>
                      
                      <h4 className="font-semibold text-indigo-700 mt-4 mb-2">Common Errors</h4>
                      <div className="space-y-2">
                        <div className="flex items-start gap-2">
                          <div className="text-red-500 mt-1">✗</div>
                          <div>If it <span className="line-through">will rain</span>, I will take an umbrella. (future in if-clause)</div>
                        </div>
                        <div className="flex items-start gap-2">
                          <div className="text-green-600 mt-1">✓</div>
                          <div>If it <span className="font-bold">rains</span>, I will take an umbrella.</div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="text-center pt-4">
                  <Button className="text-indigo-700 bg-white hover:bg-indigo-50" variant="outline" asChild>
                    <a href="/grammar/conditionals">
                      View All Conditionals
                    </a>
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="articles">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BookOpen className="h-5 w-5 text-indigo-600" />
                Articles (a, an, the)
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-bold mb-3">Indefinite Articles: a/an</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <h4 className="font-semibold text-indigo-700 mb-2">Usage</h4>
                      <ul className="list-disc pl-5 space-y-1">
                        <li>First mention o
(Content truncated due to size limit. Use line ranges to read in chunks)