# IELTS Writing Question Types - Examples and Strategies

This document provides clear examples of each IELTS Writing question type, along with strategies for approaching them effectively. Each example is designed to help you understand the format and requirements of different question types you'll encounter in the IELTS Writing test.

## Task 1 (Academic): Chart/Graph Description

### Example:

**The graph below shows the percentage of households with internet access in four different countries between 2000 and 2020.**

**Summarize the information by selecting and reporting the main features, and make comparisons where relevant.**

[Note: In an actual test, this would include a line graph showing internet access percentages for four countries over the 20-year period]

#### Sample Answer (Band 7-7.5):

The line graph illustrates the proportion of households with internet access in four countries (Country A, B, C, and D) over a 20-year period from 2000 to 2020.

Overall, all four countries experienced a significant increase in household internet access during this period, though at different rates and from different starting points. Country A consistently maintained the highest percentage throughout the entire period, while Country D showed the most dramatic improvement.

In 2000, Country A already had approximately 45% of households connected to the internet, followed by Country B at around 30%. Countries C and D had much lower initial rates of about 15% and 5% respectively. 

Between 2000 and 2010, all countries showed steady growth, with Country A reaching 70%, Country B 60%, Country C 40%, and Country D 30% by the end of the decade. The period from 2010 to 2020 saw accelerated growth for Countries C and D, with Country D's growth being particularly remarkable, rising from 30% to 85% and overtaking both Countries B and C by 2020. Country A continued its upward trend, reaching 90% by 2020, while Country B's growth slowed somewhat, reaching only 75% by the end of the period.

The most notable convergence occurred between 2015 and 2020, when the gap between the highest and lowest percentages narrowed considerably, suggesting a global trend toward universal internet access across these diverse countries.

(193 words)

### Strategy:
- Begin with an introduction that paraphrases the question
- Include an overview paragraph identifying the main trends
- Select key features (highest/lowest values, significant changes, notable patterns)
- Group data logically (by time periods or by countries)
- Make meaningful comparisons between data points
- Use a variety of language to describe trends (increase, decrease, remain stable, etc.)
- Use appropriate tenses (past tense for historical data, present perfect for connecting past to present)
- Aim for 170-190 words

## Task 1 (Academic): Process Diagram

### Example:

**The diagram below shows the process of making chocolate from cacao beans.**

**Summarize the information by selecting and reporting the main features, and make comparisons where relevant.**

[Note: In an actual test, this would include a diagram showing the chocolate-making process]

#### Sample Answer (Band 7-7.5):

The diagram illustrates the sequence of steps involved in transforming cacao beans into chocolate products.

The process begins with harvesting cacao pods from trees, which are then split open to extract the beans. These beans, covered in a white pulp, undergo a fermentation period of approximately five to seven days, during which they develop their characteristic flavor. Following fermentation, the beans are spread out and dried in the sun for about one to two weeks until their moisture content is significantly reduced.

Once dried, the beans are transported to manufacturing facilities where they are cleaned and roasted at temperatures between 120°C and 150°C. This roasting process, which typically lasts 15 to 40 minutes, further develops the flavor and removes any remaining moisture. The roasted beans are then cracked and winnowed to remove their outer shells, leaving behind cacao nibs.

These nibs are ground into a thick paste called chocolate liquor, which contains both cocoa solids and cocoa butter. For dark chocolate, this liquor is mixed with sugar and additional cocoa butter, while milk chocolate production requires the addition of milk powder. The mixture then undergoes conching, a process of heating and grinding that can last from several hours to several days, improving the texture and flavor. Finally, the refined chocolate is tempered (carefully cooled and reheated) before being molded into its final form and packaged for distribution.

(215 words)

### Strategy:
- Begin with an introduction that describes what the diagram shows
- Organize your description logically, following the sequence of the process
- Use appropriate sequence markers (first, then, next, finally, etc.)
- Include all significant stages of the process
- Use passive voice where appropriate (beans are harvested, chocolate is tempered)
- Include relevant details such as temperatures, durations, or measurements if provided
- Maintain a formal, objective tone
- Aim for 170-190 words

## Task 1 (Academic): Table Description

### Example:

**The table below shows the percentage of the population living in urban areas in different regions of the world in 1950, 2000, and 2050 (projected).**

**Summarize the information by selecting and reporting the main features, and make comparisons where relevant.**

[Note: In an actual test, this would include a table with urbanization percentages for different world regions across three time periods]

#### Sample Answer (Band 7-7.5):

The table presents data on urban population percentages across various world regions at three points in time: 1950, 2000, and projected figures for 2050.

Overall, there is a clear upward trend in urbanization across all regions, though the rate and extent of this trend vary considerably. North America and Europe started with the highest urbanization levels in 1950 and are projected to maintain relatively high percentages by 2050, while Africa shows the most dramatic projected increase over the entire 100-year period.

In 1950, North America had the highest proportion of urban dwellers at 64%, followed by Europe at 52%. In contrast, Africa and Asia had much lower urbanization rates of 15% and 18% respectively. Latin America and Oceania fell in the middle range with 41% and 62% respectively.

By 2000, all regions had experienced significant increases in urban population. Latin America showed the most remarkable change, rising by 34 percentage points to 75%. Africa and Asia both approximately doubled their urban percentages to 35% and 37% respectively, while the already highly urbanized regions saw more modest increases.

The projections for 2050 suggest continued urbanization across all regions, with Africa expected to experience the most substantial growth, reaching 62% (a 47-percentage point increase from 1950). By 2050, all regions except Africa are projected to have urban population percentages above 70%, with North America and Latin America exceeding 90%.

(208 words)

### Strategy:
- Begin with an introduction that describes what the table shows
- Include an overview paragraph identifying the main trends
- Select key data points rather than describing every figure
- Group data logically (by time periods or by regions)
- Make meaningful comparisons between different data points
- Use a variety of language to describe proportions and changes
- Use appropriate tenses (past for historical data, future/conditional for projections)
- Aim for 170-190 words

## Task 1 (Academic): Map Description

### Example:

**The maps below show the changes in a coastal town between 1995 and 2020.**

**Summarize the information by selecting and reporting the main features, and make comparisons where relevant.**

[Note: In an actual test, this would include two maps showing the town layout in 1995 and 2020]

#### Sample Answer (Band 7-7.5):

The maps illustrate the transformation of a coastal town over a 25-year period from 1995 to 2020.

Overall, the town has undergone significant development, transitioning from a small residential area with minimal facilities to a larger, more diversified urban center with expanded infrastructure and tourist amenities. The most notable changes include the expansion of residential areas, the development of the harbor, and the addition of recreational facilities.

In 1995, the town was primarily characterized by a small residential area located in the northwest, a fishing harbor on the eastern coast, and a main road running north to south through the center. A small beach area existed on the southern coast, but there were few other notable features.

By 2020, the residential area had expanded considerably eastward and southward, more than doubling in size. The former fishing harbor had been transformed into a marina with a yacht club and restaurant, suggesting a shift from industrial to recreational use. A hotel complex had been constructed along the southern beach, which itself had been extended and developed with facilities for tourists.

Additionally, a new park had been created in the central area, a shopping center had been built along the main road, and a secondary road network had been developed to connect the expanded residential areas with the new amenities. The western coastline, which was undeveloped in 1995, now featured a golf course, further emphasizing the town's evolution toward tourism and recreation.

(219 words)

### Strategy:
- Begin with an introduction that describes what the maps show
- Include an overview paragraph identifying the main changes
- Organize your description logically (by areas or by types of changes)
- Use appropriate location language (north, southeast, coastal, etc.)
- Make clear comparisons between the two time periods
- Use a variety of language to describe changes (expanded, transformed, developed, etc.)
- Use appropriate tenses (past simple for the earlier map, present simple for the current map)
- Aim for 170-190 words

## Task 1 (General Training): Letter Writing

### Example:

**You recently stayed in a hotel during a business trip. When you returned home, you realized you left an important document in your hotel room.**

**Write a letter to the hotel manager. In your letter:**
- explain your situation
- describe the document
- explain what you would like the manager to do

**Write at least 150 words.**

#### Sample Answer (Band 7-7.5):

Dear Sir/Madam,

I am writing regarding my recent stay at The Grand Hotel from 15-17 May 2025, during which I was in room 412 for a business conference.

Upon returning home yesterday, I realized that I inadvertently left an important document in the room. The document is a blue leather portfolio containing original signed contracts between my company, TechInnovate Ltd, and a new client. The portfolio has my company's logo embossed on the front cover and contains approximately 15 pages of legal documents with original signatures in blue ink. I believe I left it either in the desk drawer or possibly on the bedside table.

I would greatly appreciate it if you could check if the cleaning staff found this portfolio. If located, I would like to arrange for it to be sent to me via courier service at my expense, as these documents are irreplaceable and urgently needed for an upcoming meeting. I can be reached at john.smith@techinnovate.com or on my mobile at +44 7700 900123 to make the necessary arrangements.

Thank you for your assistance in this matter.

Yours faithfully,

John Smith

(177 words)

### Strategy:
- Use the appropriate letter format with opening and closing salutations
- Address all three bullet points in the task
- Organize your letter logically with clear paragraphs
- Include relevant details to make your letter realistic
- Use a polite, formal tone for business correspondence
- Use a mix of simple and complex sentence structures
- Include specific details (dates, room numbers, contact information)
- Aim for 170-190 words

## Task 2 (Academic/General Training): Opinion Essay

### Example:

**Some people believe that universities should focus on providing academic skills, while others think that preparing students for employment is more important.**

**Discuss both these views and give your own opinion.**

**Give reasons for your answer and include any relevant examples from your own knowledge or experience.**

**Write at least 250 words.**

#### Sample Answer (Band 7-7.5):

The purpose of higher education has been debated extensively, with some arguing that universities should prioritize academic development, while others contend that employment preparation should take precedence. This essay will examine both perspectives before presenting my own view that an integrated approach offers the most value.

Proponents of academically-focused education maintain that universities should primarily cultivate intellectual capabilities and theoretical understanding. They argue that higher education's fundamental purpose is to develop critical thinking, research skills, and comprehensive knowledge within specific disciplines. This traditional view emphasizes that universities should not be reduced to vocational training centers but should foster intellectual curiosity and academic rigor. Furthermore, a strong theoretical foundation often provides graduates with the adaptability to navigate changing career landscapes throughout their lives, rather than preparing them for specific jobs that may become obsolete.

Conversely, those advocating for employment-oriented education highlight the practical realities facing graduates. With rising tuition costs and competitive job markets, students increasingly view university education as an investment that should yield tangible career outcomes. Supporters of this perspective argue that universities have a responsibility to ensure graduates possess the practical skills, technological proficiency, and professional competencies demanded by employers. They point to the frustration of graduates who discover a significant gap between their academic knowledge and workplace requirements.

In my view, this dichotomy presents a false choice. The most effective university education integrates academic rigor with practical application. For instance, medical schools combine theoretical understanding of human physiology with clinical practice, producing graduates who are both knowledgeable and capable. Similarly, engineering programs that incorporate industry partnerships and practical projects alongside theoretical coursework prepare students more comprehensively for professional challenges.

Universities can achieve this balance through various approaches, such as incorporating internships into degree requirements, involving industry professionals in curriculum development, and designing assessments that evaluate both theoretical understanding and practical application. Additionally, interdisciplinary programs that break down traditional academic silos often better reflect the complex, multifaceted nature of real-world problems.

In conclusion, while the tension between academic focus and employment preparation is real, universities serve students best when they integrate both elements. By fostering both intellectual development and practical capabilities, higher education can prepare graduates not just for their first job, but for lifelong career success and meaningful contributions to society.

(367 words)

### Strategy:
- Begin with an introduction that paraphrases the question and outlines your approach
- Present both viewpoints fairly and in detail
- Support each viewpoint with examples or explanations
- Clearly state your own opinion
- Develop your arguments logically with clear paragraphs
- Use a range of vocabulary related to education and employment
- Use a variety of complex sentence structures
- Include a 
(Content truncated due to size limit. Use line ranges to read in chunks)