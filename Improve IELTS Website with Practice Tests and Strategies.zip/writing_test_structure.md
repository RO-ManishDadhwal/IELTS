# IELTS Writing Practice Tests Structure

## Overview
This document outlines the structure for 50 Cambridge-style IELTS Writing practice tests at Band 7+ level. Each test will follow the official IELTS Writing test format and include model answers with detailed analysis.

## Test Format
- **Academic Writing**: 2 tasks (Task 1: Report; Task 2: Essay)
- **General Training Writing**: 2 tasks (Task 1: Letter; Task 2: Essay)
- **Total Time**: 60 minutes (recommended: 20 minutes for Task 1, 40 minutes for Task 2)
- **Word Count**: Task 1: minimum 150 words; Task 2: minimum 250 words

## Structure for Each Practice Test
1. **Test Introduction**
   - Test number and source reference
   - Instructions and time allocation
   - Target band score indication (7-7.5)

2. **Task 1 (Academic)**
   - Visual information (graph, table, chart, diagram, or process)
   - Clear task instructions
   - Word count requirement (150+ words)
   - Time recommendation (20 minutes)

3. **Task 1 (General Training)**
   - Letter writing scenario
   - Purpose of letter (formal, semi-formal, or informal)
   - Points to include in the letter
   - Word count requirement (150+ words)
   - Time recommendation (20 minutes)

4. **Task 2 (Both Academic and General Training)**
   - Essay question on general interest topic
   - Clear task instructions
   - Word count requirement (250+ words)
   - Time recommendation (40 minutes)

5. **Model Answers**
   - Band 7+ model answer for Task 1
   - Band 7+ model answer for Task 2
   - Word count of model answers

6. **Detailed Analysis**
   - Task achievement analysis
   - Coherence and cohesion analysis
   - Lexical resource analysis
   - Grammatical range and accuracy analysis
   - Examiner comments and feedback
   - Band score justification

7. **Writing Strategies**
   - Task-specific approach strategies
   - Time management tips
   - Structure recommendations
   - Language enhancement suggestions
   - Common pitfalls to avoid

8. **Vocabulary and Phrases**
   - Topic-specific vocabulary
   - Useful phrases and expressions
   - Advanced grammatical structures
   - Transition signals and linking devices

## Sample Test Structure
```
WRITING TEST 1 (Band 7-7.5)

TASK 1 (Academic)
[Visual information: graph/chart/table/diagram/process]
[Task instructions]

OR

TASK 1 (General Training)
[Letter writing scenario]
[Task instructions]

TASK 2
[Essay question]
[Task instructions]

MODEL ANSWER - TASK 1
[Band 7+ sample answer]
[Word count: 150+]

MODEL ANSWER - TASK 2
[Band 7+ sample answer]
[Word count: 250+]

DETAILED ANALYSIS
[Comprehensive analysis of both tasks]

WRITING STRATEGIES
[Specific strategies for this test]

VOCABULARY AND PHRASES
[Useful language for this test]
```

## Implementation Notes
- Each test will be saved as a separate markdown file
- Tests will be numbered from 1 to 50
- All tests will maintain consistent formatting
- Tests will cover a wide range of topics to ensure comprehensive preparation
- Model answers will demonstrate Band 7-7.5 level writing
- Analysis will focus on how to achieve the target band score
- Both Academic and General Training versions will be provided
