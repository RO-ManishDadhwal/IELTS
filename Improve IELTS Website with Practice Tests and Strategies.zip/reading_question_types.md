# IELTS Reading Question Types - Examples and Strategies

This document provides clear examples of each IELTS Reading question type, along with strategies for approaching them effectively. Each example is designed to help you understand the format and requirements of different question types you'll encounter in the IELTS Reading test.

## 1. Multiple Choice Questions

### Example:

**Read the following passage about sleep patterns:**

Sleep is a naturally recurring state characterized by reduced or absent consciousness, relatively suspended sensory activity, and inactivity of nearly all voluntary muscles. It is distinguished from wakefulness by a decreased ability to react to stimuli, and it is more easily reversible than hibernation or coma. Sleep occurs in repeating periods, during which the body alternates between two distinct modes: REM sleep and non-REM sleep. REM stands for "rapid eye movement" and is associated with dreaming.

The most striking feature of REM sleep is atonia, or the temporary paralysis of the body's muscles. This prevents sleepers from acting out their dreams. The brain consumes as much oxygen during REM sleep as it does when awake. Non-REM sleep is divided into three stages: N1, N2, and N3. Each stage is characterized by increasingly deeper sleep. Stage N3, also known as deep sleep or slow-wave sleep, is the deepest sleep stage and is characterized by delta waves in the brain.

Sleep follows a circadian rhythm, which means it is regulated by the body's internal clock. This clock is influenced by environmental cues, particularly light, which is why exposure to screens before bedtime can disrupt sleep patterns. The average adult requires between 7-9 hours of sleep per night, although individual needs vary. Chronic sleep deprivation has been linked to a range of health problems, including impaired cognitive function, weakened immune system, and increased risk of cardiovascular disease.

**Questions:**

1. According to the passage, what is the main characteristic of REM sleep?
   A. Delta waves in the brain
   B. Temporary muscle paralysis
   C. Reduced oxygen consumption
   D. Division into three stages

2. Which of the following is NOT mentioned as a consequence of chronic sleep deprivation?
   A. Weakened immune system
   B. Weight gain
   C. Impaired cognitive function
   D. Increased risk of cardiovascular disease

**Answers:**
1. B - The passage states "The most striking feature of REM sleep is atonia, or the temporary paralysis of the body's muscles."
2. B - Weight gain is not mentioned in the passage as a consequence of chronic sleep deprivation.

### Strategy:
- Read the questions first to know what information to look for
- Scan the passage for keywords related to the questions
- Eliminate obviously incorrect options
- Be careful of distractors that contain information from the text but don't answer the specific question
- Double-check your answer against the passage

## 2. Identifying Information (True/False/Not Given)

### Example:

**Read the following passage about urban farming:**

Urban farming, the practice of cultivating food in urban areas, has gained significant popularity in recent years. From rooftop gardens in New York City to vertical farms in Singapore, urban agriculture is transforming how city dwellers interact with food production. These initiatives not only provide fresh produce to urban communities but also help reduce the carbon footprint associated with transporting food from rural areas to cities.

One of the main benefits of urban farming is improved food security, particularly in areas known as "food deserts" where access to fresh, nutritious food is limited. By growing food locally, urban farms can provide communities with fresh produce that might otherwise be unavailable or unaffordable. Additionally, urban farms can serve as educational spaces where residents, especially children, can learn about food production and develop a greater appreciation for nutrition and sustainability.

Urban farming faces several challenges, including limited space, potential soil contamination, and restrictive zoning laws. Innovative solutions such as vertical farming, hydroponics, and aquaponics have emerged to address space limitations. These technologies allow for higher yields in smaller areas compared to traditional farming methods. However, the initial investment required for these technologies can be substantial, making them inaccessible to some communities without external funding or support.

**Questions:**

Decide if the following statements agree with the information given in the passage.
Write TRUE if the statement agrees with the information
FALSE if the statement contradicts the information
NOT GIVEN if there is no information on this

1. Urban farming is more energy-efficient than traditional rural farming.
2. Food deserts are areas with limited access to fresh, nutritious food.
3. Vertical farming requires less water than traditional farming methods.
4. Urban farms can help reduce carbon emissions associated with food transportation.

**Answers:**
1. NOT GIVEN - The passage does not compare the energy efficiency of urban farming to traditional rural farming.
2. TRUE - The passage defines food deserts as "areas where access to fresh, nutritious food is limited."
3. NOT GIVEN - While vertical farming is mentioned as a space-efficient method, there is no information about its water usage compared to traditional farming.
4. TRUE - The passage states that urban agriculture helps "reduce the carbon footprint associated with transporting food from rural areas to cities."

### Strategy:
- Understand the difference between FALSE (contradicts information in the text) and NOT GIVEN (information not mentioned in the text)
- Look for specific information rather than making assumptions
- Be careful not to use your own knowledge about the topic
- Pay attention to qualifying words (some, all, most, never, etc.)
- Read the entire passage before answering

## 3. Matching Headings

### Example:

**Read the following passage about coral reefs:**

**Paragraph A**
Coral reefs are diverse underwater ecosystems held together by calcium carbonate structures secreted by corals. They are built by colonies of tiny animals found in marine waters containing few nutrients. Most coral reefs are built from stony corals, whose polyps cluster in groups. Coral reefs are some of the most diverse ecosystems in the world, housing tens of thousands of marine species.

**Paragraph B**
Despite occupying less than 0.1% of the world's ocean surface, coral reefs provide habitat for at least 25% of all marine species. This includes fish, mollusks, worms, crustaceans, echinoderms, sponges, tunicates, and other cnidarians. Coral reefs are also home to a wide variety of other organisms, including sea turtles, seabirds, and marine mammals, which use them for feeding, reproduction, and shelter.

**Paragraph C**
Coral reefs face numerous threats from human activities. Pollution, overfishing, destructive fishing practices, and ocean acidification have led to the degradation of many reef systems worldwide. Climate change, particularly rising ocean temperatures, has resulted in coral bleaching events where corals expel the symbiotic algae living in their tissues, causing them to turn white and often die.

**Paragraph D**
Conservation efforts for coral reefs include the establishment of marine protected areas, sustainable fishing practices, and pollution control measures. Scientists are also exploring coral restoration techniques, such as coral gardening and assisted evolution, to help reefs recover and adapt to changing conditions. Public awareness campaigns aim to educate people about the importance of coral reefs and how individual actions can impact these fragile ecosystems.

**Questions:**

Choose the correct heading for each paragraph from the list of headings below.

List of Headings:
i. The economic value of coral reefs
ii. Basic structure and composition of coral reefs
iii. The remarkable biodiversity of coral reefs
iv. Threats to coral reef ecosystems
v. Efforts to protect and restore coral reefs
vi. The discovery of new coral species
vii. Coral reef distribution around the world
viii. The relationship between corals and algae

1. Paragraph A
2. Paragraph B
3. Paragraph C
4. Paragraph D

**Answers:**
1. ii - Paragraph A describes the basic structure and composition of coral reefs.
2. iii - Paragraph B focuses on the biodiversity of coral reefs and the many species they support.
3. iv - Paragraph C discusses various threats to coral reef ecosystems.
4. v - Paragraph D outlines efforts to protect and restore coral reefs.

### Strategy:
- Read all headings first to understand the range of topics
- Identify the main idea of each paragraph (usually in the first or last sentence)
- Match paragraphs to headings based on the overall theme, not just individual words
- Eliminate headings that clearly don't match any paragraphs
- Check your answers by confirming that each heading accurately summarizes its paragraph

## 4. Matching Information

### Example:

**Read the following passage about the history of chocolate:**

**Paragraph A**
Chocolate is made from the fruit of cacao trees, native to Central and South America. The fruits are called pods, and each pod contains around 40 cacao beans. The beans are dried and roasted to create cocoa beans. The Olmecs, living in present-day Mexico as early as 1500 BCE, were likely the first humans to consume chocolate, originally prepared as a drink. However, the Olmecs left no written records about how they prepared cacao.

**Paragraph B**
The Maya civilization cultivated cacao trees in their backyard gardens and used the cacao beans to prepare a thick, unsweetened drink called "xocolatl," flavored with chili peppers and cornmeal. This bitter drink was reserved for the elite of Maya society and was often consumed during sacred ceremonies. The Maya also used cacao beans as currency, demonstrating the value they placed on this resource.

**Paragraph C**
When the Spanish conquistadors arrived in the Americas, they were introduced to chocolate by the Aztecs. Montezuma II, the Aztec emperor, reportedly drank gallons of chocolate each day for energy and as an aphrodisiac. The Spanish brought chocolate back to Europe in the 16th century, where it was initially consumed as a medicinal drink. Sugar was added to counteract the natural bitterness, transforming it into a more palatable beverage.

**Paragraph D**
The invention of the cocoa press in 1828 by Dutch chemist Coenraad Johannes van Houten revolutionized chocolate production. This device could separate cocoa butter from roasted cacao beans, resulting in a fine cocoa powder that could be mixed with liquids and other ingredients. This innovation led to the creation of solid chocolate. In 1847, British chocolatier Joseph Fry produced the first solid chocolate bar by adding cocoa butter back into the cocoa powder.

**Questions:**

The reading passage has four paragraphs, A-D.
Which paragraph contains the following information?
Write the correct letter, A-D, in boxes 1-5 on your answer sheet.

1. The transformation of chocolate from a bitter drink to a sweeter beverage
2. The first creation of solid chocolate for eating
3. The use of cacao beans as money
4. The consumption of chocolate by an indigenous ruler
5. The earliest known human consumption of chocolate

**Answers:**
1. C - Paragraph C mentions that "Sugar was added to counteract the natural bitterness, transforming it into a more palatable beverage."
2. D - Paragraph D states that "In 1847, British chocolatier Joseph Fry produced the first solid chocolate bar."
3. B - Paragraph B notes that "The Maya also used cacao beans as currency."
4. C - Paragraph C mentions that "Montezuma II, the Aztec emperor, reportedly drank gallons of chocolate each day."
5. A - Paragraph A states that "The Olmecs, living in present-day Mexico as early as 1500 BCE, were likely the first humans to consume chocolate."

### Strategy:
- Read the questions first to know what specific information to look for
- Scan each paragraph for keywords related to the questions
- Be precise in identifying where the exact information appears
- Don't be misled by similar information that doesn't exactly match what the question asks
- Double-check your answers by confirming the information is explicitly stated in the paragraph

## 5. Matching Features

### Example:

**Read the following passage about renewable energy sources:**

**Wind Energy**
Wind power harnesses the kinetic energy of moving air to generate electricity. Modern wind turbines, typically grouped in wind farms, can range from small residential turbines to massive offshore installations. While wind energy is clean and renewable, its intermittent nature presents challenges for grid stability. Wind power capacity has grown significantly in the past decade, with countries like China, the United States, and Germany leading global installation.

**Solar Energy**
Solar power converts sunlight directly into electricity using photovoltaic cells or indirectly through concentrated solar power systems. The cost of solar panels has decreased dramatically in recent years, making solar energy increasingly competitive with fossil fuels. Solar installations range from rooftop panels for individual homes to vast solar farms spanning hundreds of acres. Like wind energy, solar power generation is variable, depending on weather conditions and daylight hours.

**Hydroelectric Power**
Hydroelectric power generates electricity by harnessing the energy of flowing water, typically through dams that create reservoirs. It is one of the oldest and largest sources of renewable energy worldwide. Unlike wind and solar, hydroelectric power can provide consistent baseline power and can be quickly adjusted to meet changing demand. However, large dam projects can significantly impact local ecosystems and sometimes require the displacement of communities.

**Geothermal Energy**
Geothermal energy utilizes heat from the Earth's core to generate electricity or provide direct heating. Geothermal power plants typically operate in areas with high geothermal activity, such as regions with hot springs or geysers. This energy source provides consistent, reliable power regardless of weather conditions or time of day. However, geothermal resources are geographically limited, and the initial drilling and infrastructure costs can be substantial.

**Questions:**

Match each statement with the correct renewable energy source, A-D.
Write the correct letter, A-D, in boxes 1-6 on your answer sheet.

A. Wind Energy
B. Solar Energy
C. Hydroelectric Power
D. Geothermal Energy

1. Has seen a significant reduction in technology costs recently
2. Can quickly adjust electricity generation based on demand
3. Requires specific geological conditions to be viable
4. Is affected by daily and seasonal light variations
5. Involves potential displacement of human populations
6. Has China as one of its leading global producers

**Answers:**
1. B - Solar Energy: "The cost of solar panels has decreased dramatically in recent years"
2. C - Hydroelectric Power: "can be quickly adjusted to meet changing demand"
3. D - Geothermal Energy: "typically operate in areas with high geothermal activity"
4. B - Solar Energy: "depending on weather conditions and daylight hours"
5. C - Hydroelectric Power: "sometimes require the displacement of communities"
6. A - Wind Energy: "with countries like China, the United States, and Germany leading global installation"

### Strategy:
- Read all the features first to understand what you're looking for
- Scan each section for specific information related to the features
- Look for exact matches rather than making assumptions
- Eliminate options as you go to narrow down possibilities for remaining features
- Check that each feature clearly matches only one option

## 6. Sentence
(Content truncated due to size limit. Use line ranges to read in chunks)