import React from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { CheckCircle2, AlertCircle, Info } from 'lucide-react';

interface StrategyGuidePageProps {
  section: 'reading' | 'writing' | 'listening' | 'speaking';
  targetBand: string;
}

const StrategyGuidePage: React.FC<StrategyGuidePageProps> = ({ section, targetBand }) => {
  const sectionColors = {
    reading: 'text-blue-700',
    writing: 'text-green-700',
    listening: 'text-purple-700',
    speaking: 'text-orange-700'
  };

  const sectionBgColors = {
    reading: 'bg-blue-50',
    writing: 'bg-green-50',
    listening: 'bg-purple-50',
    speaking: 'bg-orange-50'
  };

  const sectionTitle = section.charAt(0).toUpperCase() + section.slice(1);
  
  return (
    <div className="container mx-auto px-4 py-12">
      <div className="text-center mb-12">
        <h1 className={`text-4xl font-bold mb-4 ${sectionColors[section]}`}>
          IELTS {sectionTitle} Strategy Guide
        </h1>
        <p className="text-xl text-gray-600 max-w-3xl mx-auto">
          Comprehensive strategies to help you achieve Band {targetBand} in the IELTS {sectionTitle} section.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-12">
        <div className="lg:col-span-2">
          <div className={`${sectionBgColors[section]} p-6 rounded-lg mb-8`}>
            <h2 className="text-2xl font-bold mb-4">What Band {targetBand} Requires</h2>
            <p className="mb-4">
              {section === 'reading' ? 
                `To achieve Band ${targetBand} in Reading, you need to demonstrate excellent comprehension of complex texts, identify fine distinctions in meaning, recognize implicit meanings and attitudes, and process information quickly and accurately.` :
              section === 'writing' ? 
                `To achieve Band ${targetBand} in Writing, you need to address all parts of the task with clear positions, use a variety of complex structures with good grammatical control, demonstrate a wide vocabulary range, and organize your ideas coherently.` :
              section === 'listening' ? 
                `To achieve Band ${targetBand} in Listening, you need to understand virtually everything you hear with rare difficulties, follow complex arguments, recognize implicit meanings, and process information quickly and accurately.` :
                `To achieve Band ${targetBand} in Speaking, you need to speak at length without noticeable effort, use a range of connectives and discourse markers flexibly, demonstrate good vocabulary resources, and maintain good grammatical control with clear pronunciation.`
              }
            </p>
            <Button className={`${sectionColors[section]} bg-white hover:bg-gray-50`} variant="outline" asChild>
              <a href={`/strategy-guides/${section}/band${targetBand.replace('.', '-')}`}>
                View Full Band Descriptors
              </a>
            </Button>
          </div>

          <Tabs defaultValue="core-strategies">
            <TabsList className="mb-6">
              <TabsTrigger value="core-strategies">Core Strategies</TabsTrigger>
              <TabsTrigger value="common-pitfalls">Common Pitfalls</TabsTrigger>
              <TabsTrigger value="practice-plan">Practice Plan</TabsTrigger>
              <TabsTrigger value="test-day">Test Day Tips</TabsTrigger>
            </TabsList>
            
            <TabsContent value="core-strategies">
              <Card>
                <CardHeader>
                  <CardTitle>Core Strategies for Band {targetBand} Success</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  {section === 'reading' ? (
                    <>
                      <div>
                        <h3 className="text-lg font-bold mb-2">Strategic Reading Approach</h3>
                        <p>Learn to approach each passage with a three-phase strategy: strategic overview, question-focused reading, and final check. This maximizes both comprehension and time efficiency.</p>
                      </div>
                      <div>
                        <h3 className="text-lg font-bold mb-2">Advanced Vocabulary Skills</h3>
                        <p>Develop context-based inference skills, synonym recognition, and mastery of the Academic Word List to handle complex texts effectively.</p>
                      </div>
                      <div>
                        <h3 className="text-lg font-bold mb-2">Time Management Excellence</h3>
                        <p>Apply the 20-20-20 rule, question prioritization, and speed reading techniques to complete all questions within the time limit.</p>
                      </div>
                      <div>
                        <h3 className="text-lg font-bold mb-2">Question Type-Specific Strategies</h3>
                        <p>Master specialized approaches for each question type, from multiple choice to matching headings to completion tasks.</p>
                      </div>
                    </>
                  ) : section === 'writing' ? (
                    <>
                      <div>
                        <h3 className="text-lg font-bold mb-2">Task 1 Strategies</h3>
                        <p>Learn to analyze different chart types, create effective overviews, select key features, and use appropriate language for data description.</p>
                      </div>
                      <div>
                        <h3 className="text-lg font-bold mb-2">Task 2 Strategies</h3>
                        <p>Master different essay types, develop strong introductions and conclusions, and create well-structured body paragraphs with clear examples.</p>
                      </div>
                      <div>
                        <h3 className="text-lg font-bold mb-2">Advanced Language Skills</h3>
                        <p>Incorporate complex sentence structures, advanced cohesive devices, and academic vocabulary to elevate your writing to Band 7-7.5 level.</p>
                      </div>
                      <div>
                        <h3 className="text-lg font-bold mb-2">Time Management</h3>
                        <p>Allocate your 60 minutes effectively with 20 minutes for Task 1 and 40 minutes for Task 2, including planning and review time.</p>
                      </div>
                    </>
                  ) : section === 'listening' ? (
                    <>
                      <div>
                        <h3 className="text-lg font-bold mb-2">Advanced Prediction Techniques</h3>
                        <p>Develop pre-question analysis, context visualization, and answer type preparation to anticipate information before you hear it.</p>
                      </div>
                      <div>
                        <h3 className="text-lg font-bold mb-2">Precision Listening Skills</h3>
                        <p>Train to discriminate similar sounds, recognize numbers and letters accurately, and identify corrections and changes in speech.</p>
                      </div>
                      <div>
                        <h3 className="text-lg font-bold mb-2">Note-Taking Excellence</h3>
                        <p>Create efficient symbols and abbreviations, capture strategic information, and refine your notes during the recording.</p>
                      </div>
                      <div>
                        <h3 className="text-lg font-bold mb-2">Advanced Distractor Management</h3>
                        <p>Learn to recognize deliberate traps, develop synonym awareness, and apply inference skills to avoid common pitfalls.</p>
                      </div>
                    </>
                  ) : (
                    <>
                      <div>
                        <h3 className="text-lg font-bold mb-2">Part 1 Strategies</h3>
                        <p>Develop question anticipation, response structure using the AREL technique, and natural conversation development for familiar topics.</p>
                      </div>
                      <div>
                        <h3 className="text-lg font-bold mb-2">Part 2 Strategies</h3>
                        <p>Master effective preparation, structural frameworks, content development, and time management for the individual long turn.</p>
                      </div>
                      <div>
                        <h3 className="text-lg font-bold mb-2">Part 3 Strategies</h3>
                        <p>Enhance critical thinking, discussion development, advanced language features, and recovery techniques for the two-way discussion.</p>
                      </div>
                      <div>
                        <h3 className="text-lg font-bold mb-2">Advanced Language Skills</h3>
                        <p>Incorporate complex grammatical structures, sophisticated vocabulary, effective paraphrasing, and natural pronunciation features.</p>
                      </div>
                    </>
                  )}
                  <div className="pt-4">
                    <Button className={`${sectionColors[section]}`} asChild>
                      <a href={`/strategy-guides/${section}/band${targetBand.replace('.', '-')}/core-strategies`}>
                        View Detailed Strategies
                      </a>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="common-pitfalls">
              <Card>
                <CardHeader>
                  <CardTitle>Common Pitfalls and How to Avoid Them</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    {section === 'reading' ? (
                      <>
                        <div className="flex items-start gap-4">
                          <div className="mt-1 text-red-500">
                            <AlertCircle size={20} />
                          </div>
                          <div>
                            <h3 className="text-lg font-bold">Overthinking</h3>
                            <p className="text-gray-600">Reading too much into questions or looking for tricks when the answer is directly in the text.</p>
                            <p className="text-gray-800 mt-1"><span className="font-bold">Solution:</span> Trust the text; the answer is there, not hidden.</p>
                          </div>
                        </div>
                        
                        <div className="flex items-start gap-4">
                          <div className="mt-1 text-red-500">
                            <AlertCircle size={20} />
                          </div>
                          <div>
                            <h3 className="text-lg font-bold">Knowledge Bias</h3>
                            <p className="text-gray-600">Using outside knowledge rather than information in the text.</p>
                            <p className="text-gray-800 mt-1"><span className="font-bold">Solution:</span> Base answers solely on the passage, even if it contradicts what you know.</p>
                          </div>
                        </div>
                        
                        <div className="flex items-start gap-4">
                          <div className="mt-1 text-red-500">
                            <AlertCircle size={20} />
                          </div>
                          <div>
                            <h3 className="text-lg font-bold">Time Mismanagement</h3>
                            <p className="text-gray-600">Spending too long on difficult questions or passages.</p>
                            <p className="text-gray-800 mt-1"><span className="font-bold">Solution:</span> Stick to time limits; mark and return to difficult questions later.</p>
                          </div>
                        </div>
                      </>
                    ) : section === 'writing' ? (
                      <>
                        <div className="flex items-start gap-4">
                          <div className="mt-1 text-red-500">
                            <AlertCircle size={20} />
                          </div>
                          <div>
                            <h3 className="text-lg font-bold">Misunderstanding the Task</h3>
                            <p className="text-gray-600">Not addressing all parts of the question or misinterpreting requirements.</p>
                            <p className="text-gray-800 mt-1"><span className="font-bold">Solution:</span> Underline key words in the question and check your answer against them.</p>
                          </div>
                        </div>
                        
                        <div className="flex items-start gap-4">
                          <div className="mt-1 text-red-500">
                            <AlertCircle size={20} />
                          </div>
                          <div>
                            <h3 className="text-lg font-bold">Weak Position</h3>
                            <p className="text-gray-600">Unclear or inconsistent position throughout the essay.</p>
                            <p className="text-gray-800 mt-1"><span className="font-bold">Solution:</span> State your position clearly in introduction and maintain it throughout.</p>
                          </div>
                        </div>
                        
                        <div className="flex items-start gap-4">
                          <div className="mt-1 text-red-500">
                            <AlertCircle size={20} />
                          </div>
                          <div>
                            <h3 className="text-lg font-bold">Insufficient Development</h3>
                            <p className="text-gray-600">Making claims without supporting them with examples or explanations.</p>
                            <p className="text-gray-800 mt-1"><span className="font-bold">Solution:</span> Follow the "point, explain, example" structure for each main idea.</p>
                          </div>
                        </div>
                      </>
                    ) : section === 'listening' ? (
                      <>
                        <div className="flex items-start gap-4">
                          <div className="mt-1 text-red-500">
                            <AlertCircle size={20} />
                          </div>
                          <div>
                            <h3 className="text-lg font-bold">Losing Concentration</h3>
                            <p className="text-gray-600">Mental fatigue causing missed information during the recording.</p>
                            <p className="text-gray-800 mt-1"><span className="font-bold">Solution:</span> Practice full-length tests to build stamina; use short mental resets between sections.</p>
                          </div>
                        </div>
                        
                        <div className="flex items-start gap-4">
                          <div className="mt-1 text-red-500">
                            <AlertCircle size={20} />
                          </div>
                          <div>
                            <h3 className="text-lg font-bold">Fixating on Missed Answers</h3>
                            <p className="text-gray-600">Getting stuck on a missed question and missing subsequent ones.</p>
                            <p className="text-gray-800 mt-1"><span className="font-bold">Solution:</span> Accept missed answers and move on immediately; mark uncertain questions to revisit if time allows.</p>
                          </div>
               
(Content truncated due to size limit. Use line ranges to read in chunks)