import React from 'react';
import { Book, BookOpen, Headphones, MessageCircle, Search, BookText, GraduationCap } from 'lucide-react';
import SearchBar from './SearchBar';
import Section from './Section';

const HomePage: React.FC = () => {
  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white">
      {/* Hero Section */}
      <div className="bg-blue-700 text-white">
        <div className="container mx-auto px-4 py-16 md:py-24">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              Your Path to IELTS Success
            </h1>
            <p className="text-xl md:text-2xl mb-8 text-blue-100">
              Comprehensive preparation resources to help you achieve your target band scores
            </p>
            <div className="flex justify-center">
              <SearchBar 
                onSearch={(query) => window.location.href = `/search?q=${encodeURIComponent(query)}`}
                placeholder="Search for practice tests, strategies, grammar rules..."
              />
            </div>
          </div>
        </div>
      </div>

      {/* Main Sections */}
      <div className="container mx-auto px-4 py-12">
        <h2 className="text-3xl font-bold text-center mb-12">IELTS Test Sections</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          <Section 
            title="Reading" 
            description="Practice tests, strategies, and examples to help you achieve Band 8 in IELTS Reading."
            icon={<Book size={24} />}
            color="border-blue-700"
            url="/reading"
          />
          
          <Section 
            title="Writing" 
            description="Comprehensive guides and practice for both Task 1 and Task 2 to reach Band 7-7.5."
            icon={<BookOpen size={24} />}
            color="border-green-700"
            url="/writing"
          />
          
          <Section 
            title="Listening" 
            description="Techniques and practice tests to help you achieve Band 8.5 in the Listening section."
            icon={<Headphones size={24} />}
            color="border-purple-700"
            url="/listening"
          />
          
          <Section 
            title="Speaking" 
            description="Strategies and practice materials for all three parts to reach Band 7."
            icon={<MessageCircle size={24} />}
            color="border-orange-700"
            url="/speaking"
          />
        </div>

        <h2 className="text-3xl font-bold text-center mb-12">Additional Resources</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-16">
          <Section 
            title="Grammar Guide" 
            description="Comprehensive grammar rules with common error corrections to improve your accuracy."
            icon={<BookText size={24} />}
            color="border-red-700"
            url="/grammar"
          />
          
          <Section 
            title="Question Types" 
            description="Examples and strategies for every type of question in the IELTS test."
            icon={<Search size={24} />}
            color="border-indigo-700"
            url="/question-types"
          />
          
          <Section 
            title="Strategy Guides" 
            description="Targeted strategies to achieve your specific band score goals in each section."
            icon={<GraduationCap size={24} />}
            color="border-teal-700"
            url="/strategies"
          />
        </div>
      </div>

      {/* Features Section */}
      <div className="bg-gray-50 py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Why Choose Our Platform</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="w-12 h-12 bg-blue-100 text-blue-700 rounded-full flex items-center justify-center mb-4">
                <BookOpen size={24} />
              </div>
              <h3 className="text-xl font-bold mb-2">50 Cambridge Practice Tests</h3>
              <p className="text-gray-600">Access authentic practice materials for all four sections of the IELTS test.</p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="w-12 h-12 bg-green-100 text-green-700 rounded-full flex items-center justify-center mb-4">
                <GraduationCap size={24} />
              </div>
              <h3 className="text-xl font-bold mb-2">Targeted Band Strategies</h3>
              <p className="text-gray-600">Specific strategies designed to help you achieve your target band scores.</p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="w-12 h-12 bg-purple-100 text-purple-700 rounded-full flex items-center justify-center mb-4">
                <Search size={24} />
              </div>
              <h3 className="text-xl font-bold mb-2">Advanced Search</h3>
              <p className="text-gray-600">Find exactly what you need with our powerful search functionality.</p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="w-12 h-12 bg-orange-100 text-orange-700 rounded-full flex items-center justify-center mb-4">
                <BookText size={24} />
              </div>
              <h3 className="text-xl font-bold mb-2">Comprehensive Grammar Guide</h3>
              <p className="text-gray-600">Extensive grammar resources with common error corrections and examples.</p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="w-12 h-12 bg-red-100 text-red-700 rounded-full flex items-center justify-center mb-4">
                <MessageCircle size={24} />
              </div>
              <h3 className="text-xl font-bold mb-2">Question Type Examples</h3>
              <p className="text-gray-600">Clear examples for every question type in both reading and writing sections.</p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="w-12 h-12 bg-indigo-100 text-indigo-700 rounded-full flex items-center justify-center mb-4">
                <Headphones size={24} />
              </div>
              <h3 className="text-xl font-bold mb-2">Audio Resources</h3>
              <p className="text-gray-600">High-quality audio materials for listening and speaking practice.</p>
            </div>
          </div>
        </div>
      </div>

      {/* Call to Action */}
      <div className="bg-blue-700 text-white py-16">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-6">Ready to Start Your IELTS Journey?</h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            Begin your preparation today with our comprehensive resources designed to help you achieve your target scores.
          </p>
          <button className="bg-white text-blue-700 hover:bg-blue-50 font-bold py-3 px-8 rounded-full text-lg transition-colors">
            Get Started Now
          </button>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-gray-800 text-gray-300 py-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-white text-lg font-bold mb-4">IELTS Preparation</h3>
              <ul className="space-y-2">
                <li><a href="/reading" className="hover:text-white">Reading</a></li>
                <li><a href="/writing" className="hover:text-white">Writing</a></li>
                <li><a href="/listening" className="hover:text-white">Listening</a></li>
                <li><a href="/speaking" className="hover:text-white">Speaking</a></li>
              </ul>
            </div>
            
            <div>
              <h3 className="text-white text-lg font-bold mb-4">Resources</h3>
              <ul className="space-y-2">
                <li><a href="/practice-tests" className="hover:text-white">Practice Tests</a></li>
                <li><a href="/strategies" className="hover:text-white">Strategy Guides</a></li>
                <li><a href="/grammar" className="hover:text-white">Grammar Guide</a></li>
                <li><a href="/question-types" className="hover:text-white">Question Types</a></li>
              </ul>
            </div>
            
            <div>
              <h3 className="text-white text-lg font-bold mb-4">About</h3>
              <ul className="space-y-2">
                <li><a href="/about" className="hover:text-white">About Us</a></li>
                <li><a href="/contact" className="hover:text-white">Contact</a></li>
                <li><a href="/faq" className="hover:text-white">FAQ</a></li>
                <li><a href="/privacy" className="hover:text-white">Privacy Policy</a></li>
              </ul>
            </div>
            
            <div>
              <h3 className="text-white text-lg font-bold mb-4">Connect</h3>
              <p className="mb-4">Subscribe to our newsletter for IELTS tips and updates.</p>
              <div className="flex">
                <input 
                  type="email" 
                  placeholder="Your email" 
                  className="px-4 py-2 rounded-l-md w-full focus:outline-none text-gray-800"
                />
                <button className="bg-blue-700 hover:bg-blue-600 px-4 py-2 rounded-r-md transition-colors">
                  Subscribe
                </button>
              </div>
            </div>
          </div>
          
          <div className="border-t border-gray-700 mt-12 pt-8 text-center">
            <p>&copy; {new Date().getFullYear()} IELTS Preparation Platform. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default HomePage;
