# IELTS Reading Practice Tests Structure

## Overview
This document outlines the structure for 50 Cambridge-style IELTS Reading practice tests at Band 7+ level. Each test will follow the official IELTS Reading test format and include comprehensive answer explanations.

## Test Format
- **Academic Reading**: 3 passages with increasing difficulty
- **General Training Reading**: 3 sections with increasing difficulty
- **Total Questions**: 40 questions per complete test
- **Time Allowed**: 60 minutes
- **Question Types**: Multiple choice, identifying information, identifying writer's views/claims, matching information, matching headings, matching features, matching sentence endings, sentence completion, summary completion, note completion, table completion, flow-chart completion, diagram label completion, short-answer questions

## Structure for Each Practice Test
1. **Test Introduction**
   - Test number and source reference
   - Instructions and time allocation
   - Target band score indication (7+)

2. **Reading Passages**
   - 3 passages of approximately 700-900 words each
   - Authentic texts from books, journals, magazines, newspapers
   - Academic topics (sciences, social sciences, business) for Academic module
   - Everyday topics for General Training module

3. **Questions Section**
   - 12-14 questions per passage
   - Variety of question types in each test
   - Clear instructions for each question type
   - Word limits specified where applicable

4. **Answer Key**
   - Complete answer key with correct answers
   - Alternative acceptable answers where applicable

5. **Detailed Explanations**
   - Step-by-step explanation for each answer
   - Text references and reasoning
   - Vocabulary explanations for difficult terms
   - Reading strategies specific to question types

6. **Band Score Conversion Table**
   - Raw score to band score conversion
   - Performance analysis guidelines

7. **Reading Strategies**
   - Time management tips
   - Skimming and scanning techniques
   - Question-specific approaches
   - Common pitfalls to avoid

## Sample Test Structure
```
READING TEST 1 (Band 7+)

PASSAGE 1
[700-900 word authentic text on academic topic]

Questions 1-13
[Various question types with clear instructions]

PASSAGE 2
[700-900 word authentic text on academic topic]

Questions 14-26
[Various question types with clear instructions]

PASSAGE 3
[700-900 word authentic text on academic topic]

Questions 27-40
[Various question types with clear instructions]

ANSWER KEY
[Complete list of correct answers]

DETAILED EXPLANATIONS
[Comprehensive explanations for all answers]

BAND SCORE CONVERSION
[Raw score to band score table]

READING STRATEGIES
[Specific strategies for this test]
```

## Implementation Notes
- Each test will be saved as a separate markdown file
- Tests will be numbered from 1 to 50
- All tests will maintain consistent formatting
- Tests will cover a wide range of topics to ensure comprehensive preparation
- Difficulty will be calibrated to Band 7+ level
- Answer explanations will focus on higher-level reading skills
