import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Badge } from './ui/badge';

interface SearchResultProps {
  results: SearchResult[];
  isLoading: boolean;
}

export interface SearchResult {
  id: string;
  title: string;
  type: 'practice' | 'strategy' | 'grammar' | 'example' | 'question';
  section?: 'reading' | 'writing' | 'listening' | 'speaking';
  excerpt: string;
  url: string;
  bandScore?: string;
}

const SearchResults: React.FC<SearchResultProps> = ({ results, isLoading }) => {
  const [activeTab, setActiveTab] = useState<string>('all');
  const [filteredResults, setFilteredResults] = useState<SearchResult[]>(results);

  useEffect(() => {
    if (activeTab === 'all') {
      setFilteredResults(results);
    } else {
      setFilteredResults(results.filter(result => 
        result.section === activeTab || result.type === activeTab
      ));
    }
  }, [activeTab, results]);

  const getSectionColor = (section?: string) => {
    switch(section) {
      case 'reading': return 'bg-blue-100 text-blue-800';
      case 'writing': return 'bg-green-100 text-green-800';
      case 'listening': return 'bg-purple-100 text-purple-800';
      case 'speaking': return 'bg-orange-100 text-orange-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getTypeColor = (type: string) => {
    switch(type) {
      case 'practice': return 'bg-indigo-100 text-indigo-800';
      case 'strategy': return 'bg-red-100 text-red-800';
      case 'grammar': return 'bg-yellow-100 text-yellow-800';
      case 'example': return 'bg-teal-100 text-teal-800';
      case 'question': return 'bg-pink-100 text-pink-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-40">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-700"></div>
      </div>
    );
  }

  if (results.length === 0) {
    return (
      <Card className="w-full mt-4">
        <CardContent className="pt-6">
          <p className="text-center text-gray-500">No results found. Try different search terms.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="w-full mt-4">
      <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="mb-4">
          <TabsTrigger value="all">All Results</TabsTrigger>
          <TabsTrigger value="reading">Reading</TabsTrigger>
          <TabsTrigger value="writing">Writing</TabsTrigger>
          <TabsTrigger value="listening">Listening</TabsTrigger>
          <TabsTrigger value="speaking">Speaking</TabsTrigger>
          <TabsTrigger value="grammar">Grammar</TabsTrigger>
        </TabsList>
        
        <TabsContent value={activeTab} className="space-y-4">
          {filteredResults.map((result) => (
            <Card key={result.id} className="overflow-hidden hover:shadow-md transition-shadow">
              <CardHeader className="pb-2">
                <div className="flex justify-between items-start">
                  <CardTitle className="text-xl">{result.title}</CardTitle>
                  {result.bandScore && (
                    <Badge variant="outline" className="ml-2">
                      Band {result.bandScore}
                    </Badge>
                  )}
                </div>
                <div className="flex gap-2 mt-1">
                  {result.section && (
                    <Badge className={`${getSectionColor(result.section)}`}>
                      {result.section.charAt(0).toUpperCase() + result.section.slice(1)}
                    </Badge>
                  )}
                  <Badge className={`${getTypeColor(result.type)}`}>
                    {result.type.charAt(0).toUpperCase() + result.type.slice(1)}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">{result.excerpt}</p>
              </CardContent>
              <CardFooter className="bg-gray-50 pt-2 pb-2">
                <a 
                  href={result.url} 
                  className="text-blue-600 hover:text-blue-800 hover:underline text-sm"
                >
                  View Resource →
                </a>
              </CardFooter>
            </Card>
          ))}
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default SearchResults;
