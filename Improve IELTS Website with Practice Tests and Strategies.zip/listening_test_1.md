# Sample IELTS Listening Practice Test 1 (Band 8.5)

## TEST INTRODUCTION

This is Cambridge IELTS Listening Practice Test 1, designed to help you achieve a Band 8.5 score. The test consists of four sections, each with 10 questions. You will have approximately 30 minutes to listen to the recordings and 10 minutes to transfer your answers to the answer sheet.

## SECTION 1

Questions 1-10
Complete the notes below.
Write NO MORE THAN TWO WORDS AND/OR A NUMBER for each answer.

### HOLIDAY ACCOMMODATION BOOKING

Customer details:
- Name: Sarah (1) ____________
- Phone: (2) ____________
- Email: sarah.j84@mailbox.com

Accommodation requirements:
- Type of accommodation: (3) ____________ with sea view
- Check-in date: (4) ____________
- Number of nights: (5) ____________
- Number of adults: 2
- Number of children: (6) ____________
- Special requirements: (7) ____________ for children

Payment details:
- Total cost: (8) £____________
- Deposit required: £75
- Deposit payment method: (9) ____________
- Confirmation will be sent by (10) ____________

## SECTION 2

Questions 11-20
Complete the sentences below.
Write NO MORE THAN THREE WORDS AND/OR A NUMBER for each answer.

### COMMUNITY CENTER RENOVATION PROJECT

11. The community center was originally built in ____________.

12. The center will be closed for renovation for a period of ____________.

13. The main hall will have a new ____________ installed.

14. The capacity of the main hall will increase from 120 to ____________ people.

15. The kitchen will be equipped with new ____________.

16. A new ____________ will be built on the east side of the building.

17. The project is mainly funded by ____________.

18. Local businesses have contributed ____________ to the project.

19. Volunteers are needed to help with ____________ after the renovation.

20. People interested in volunteering should contact ____________.

## SECTION 3

Questions 21-30

Questions 21-25
Choose the correct letter, A, B, or C.

### STUDENT DISCUSSION ABOUT RESEARCH PROJECT

21. The students are discussing a project about
    A. marine pollution.
    B. coastal erosion.
    C. climate change effects.

22. According to the female student, the main problem with their current data is that
    A. it's too limited in scope.
    B. it's from unreliable sources.
    C. it's too old to be relevant.

23. The male student suggests they should
    A. change their research topic.
    B. collect their own data.
    C. consult with their professor.

24. The female student mentions that the local environmental agency
    A. has refused to help them.
    B. charges a fee for data access.
    C. has relevant data they could use.

25. The students agree to
    A. divide the research tasks equally.
    B. focus on different aspects of the topic.
    C. work together on all aspects of the project.

Questions 26-30
Complete the table below.
Write NO MORE THAN TWO WORDS for each answer.

### RESEARCH PROJECT TIMELINE

| Week | Tasks | Person Responsible |
|------|-------|-------------------|
| 1-2 | Literature review | Both students |
| 3 | Contact environmental agency and arrange (26) ____________ | Male student |
| 4 | Analyze (27) ____________ from previous studies | Female student |
| 5 | Conduct (28) ____________ with local residents | Male student |
| 6 | Create maps showing affected (29) ____________ | Female student |
| 7-8 | Write report and prepare (30) ____________ | Both students |

## SECTION 4

Questions 31-40

Questions 31-35
Complete the notes below.
Write NO MORE THAN TWO WORDS for each answer.

### LECTURE ON URBAN PLANNING

Historical approaches:
- Ancient cities were often designed for (31) ____________ purposes
- Medieval towns typically grew around (32) ____________ or castles
- 19th century industrial cities prioritized (33) ____________ over living conditions

Modern urban planning principles:
- Sustainability
- (34) ____________
- Community engagement
- (35) ____________ between different areas

Questions 36-40
Choose FIVE answers from the list, A-H, and write the correct letter next to questions 36-40.

Which FIVE challenges are mentioned as major issues in contemporary urban planning?

A. Lack of qualified urban planners
B. Population growth and density
C. Climate change adaptation
D. Political disagreements
E. Transportation systems
F. Affordable housing
G. Cultural preservation
H. Water management

36. ____________
37. ____________
38. ____________
39. ____________
40. ____________

## ANSWER KEY

### Section 1
1. Johnson
2. 07700 954 321
3. apartment
4. June 15th
5. seven
6. three
7. high chairs
8. 840
9. credit card
10. email

### Section 2
11. 1985
12. six months
13. sound system
14. 200
15. commercial appliances
16. parking lot
17. the city council
18. £50,000
19. landscaping
20. Janet Williams

### Section 3
21. B
22. A
23. B
24. C
25. B
26. interview
27. data
28. surveys
29. areas
30. presentation

### Section 4
31. defensive
32. markets
33. efficiency
34. accessibility
35. connectivity
36. B
37. C
38. E
39. F
40. H

## FULL TRANSCRIPT

### Section 1: Holiday Accommodation Booking

Receptionist: Good morning, Seaview Holiday Rentals. How can I help you?

Woman: Hello, I'd like to book some accommodation for my family holiday this summer.

Receptionist: Certainly. I'll just need to take some details. Could I have your name, please?

Woman: Yes, it's Sarah Johnson.

Receptionist: Thank you, Ms. Johnson. And could I have a contact number?

Woman: Yes, it's 07700 954 321.

Receptionist: Great. And an email address?

Woman: It's sarah.j84@mailbox.com.

Receptionist: Thank you. Now, what type of accommodation are you looking for?

Woman: We'd like an apartment with sea view if possible.

Receptionist: Yes, we have several apartments with sea views available. When would you like to check in?

Woman: We're planning to arrive on June 15th.

Receptionist: And how many nights would you like to stay?

Woman: We'd like to book for seven nights.

Receptionist: Perfect. And how many people will be staying?

Woman: There will be two adults and three children.

Receptionist: I see. Do you have any special requirements?

Woman: Yes, we'll need high chairs for the children, please.

Receptionist: That's not a problem. We can provide high chairs. Let me check availability... Yes, we have a three-bedroom apartment with sea view available for those dates. The total cost for seven nights would be £840.

Woman: That sounds good.

Receptionist: Great. To confirm the booking, we'll need a deposit of £75. How would you like to pay that?

Woman: I'll pay by credit card.

Receptionist: Perfect. I'll take those details in a moment. Once the booking is confirmed, we'll send you a confirmation by email with all the details.

Woman: Excellent, thank you.

### Section 2: Community Center Renovation Project

Good evening everyone, and thank you for coming to this information session about the upcoming renovation of our community center. As many of you know, our center was originally built in 1985 and has served the community well for many years, but it's now in need of significant updates.

I'm pleased to announce that the renovation project has been approved and will begin next month. The center will be closed for renovation for a period of six months, and we expect to reopen in early February next year.

Let me tell you about some of the improvements we'll be making. In the main hall, we'll be installing a new sound system, which will greatly improve the experience for performances and events. We'll also be expanding the main hall to increase its capacity from the current 120 to 200 people, allowing us to host larger community events.

The kitchen will be completely modernized with new commercial appliances, making it much more functional for community dinners and catering for events. On the east side of the building, we'll be building a new parking lot to address the ongoing parking issues we've experienced during popular events.

Regarding funding, the project is mainly funded by the city council, which has allocated a significant budget for this purpose. We've also received generous contributions from local businesses, who have collectively donated £50,000 toward the renovation.

Once the renovation is complete, we'll need volunteers to help with landscaping the grounds around the center. If you're interested in volunteering, please contact Janet Williams, our volunteer coordinator, who can provide more information about how you can help.

### Section 3: Student Discussion about Research Project

Male Student: So, have you had a chance to look at the research proposal I sent you?

Female Student: Yes, I have. I think your idea to focus our project on coastal erosion is good. It's definitely a significant issue in this region.

Male Student: Thanks. I thought it would be interesting to examine how it's affecting the local communities and environment.

Female Student: I agree, but I'm a bit concerned about the data we have. It's too limited in scope. We only have information from two coastal areas, and I think we need a broader perspective to make meaningful conclusions.

Male Student: You're right. What if we collect our own data? We could visit several coastal locations and document the erosion patterns ourselves.

Female Student: That could work, but it would be time-consuming. I was thinking we could also check if the local environmental agency has any data we could use. They monitor coastal changes regularly.

Male Student: That's a great idea. They might have historical data too, which would help us analyze trends over time.

Female Student: Exactly. And I think we should focus on different aspects of the topic. I could look at the environmental impact while you focus on the social and economic effects on communities.

Male Student: I like that approach. Let's create a timeline for our research. We should spend the first two weeks on the literature review to build a solid foundation.

Female Student: Agreed. Then in week three, you could contact the environmental agency and arrange an interview with one of their experts.

Male Student: Yes, and in week four, you could analyze data from previous studies to identify patterns and trends.

Female Student: For week five, why don't you conduct surveys with local residents to get their perspectives?

Male Student: Good idea. And in week six, you could create maps showing affected areas based on all the data we've collected.

Female Student: Then we can use the last two weeks to write our report and prepare a presentation for the class.

Male Student: Perfect. I think we have a solid plan now.

### Section 4: Lecture on Urban Planning

Today's lecture focuses on the evolution of urban planning and the challenges faced by modern cities. Throughout history, cities have been designed and developed according to the needs and values of their time.

In ancient civilizations, cities were often designed for defensive purposes, with walls and strategic layouts to protect inhabitants from external threats. The ancient Romans, for example, developed sophisticated urban grids that we still see in many European cities today.

Medieval towns typically grew organically around markets or castles, with narrow streets and compact living quarters. These designs reflected the economic and social structures of feudal society.

The Industrial Revolution brought dramatic changes to urban development. 19th century industrial cities prioritized efficiency over living conditions, leading to overcrowded tenements and pollution. This period eventually sparked the modern urban planning movement as reformers sought to address these problems.

Today's urban planning is guided by several key principles. Sustainability has become central, with planners considering environmental impact and resource efficiency. Accessibility is another crucial principle, ensuring that cities are navigable for people of all abilities. Community engagement has also become essential, involving residents in planning decisions. Finally, modern planning emphasizes connectivity between different areas, creating integrated urban systems rather than isolated neighborhoods.

Despite advances in urban planning theory and practice, contemporary cities face numerous challenges. Population growth and density present perhaps the most fundamental challenge, as cities struggle to accommodate growing numbers of residents while maintaining quality of life.

Climate change adaptation has become an urgent priority, with planners developing strategies to mitigate flooding, heat islands, and other climate-related risks. Transportation systems remain a persistent challenge, balancing efficiency, accessibility, and environmental impact.

Affordable housing has reached crisis levels in many global cities, requiring innovative approaches to ensure economic diversity. Water management has also emerged as a critical issue, particularly in regions experiencing drought or flooding.

These challenges require integrated approaches that consider the complex interrelationships between different urban systems. The most successful urban planning initiatives today are those that address multiple challenges simultaneously while engaging diverse stakeholders in the planning process.

## DETAILED EXPLANATIONS

### Section 1: Holiday Accommodation Booking

1. Johnson - The woman clearly states her name as "Sarah Johnson" when asked by the receptionist.

2. 07700 954 321 - This is the phone number the woman provides when asked for a contact number.

3. apartment - The woman specifically requests "an apartment with sea view" when asked about the type of accommodation.

4. June 15th - The woman states "We're planning to arrive on June 15th" when asked about the check-in date.

5. seven - When asked how many nights they would like to stay, the woman replies "We'd like to book for seven nights."

6. three - The woman mentions "two adults and three children" when asked how many people will be staying.

7. high chairs - When asked about special requirements, the woman says "we'll need high chairs for the children."

8. 840 - The receptionist states "The total cost for seven nights would be £840."

9. credit card - When asked how she would like to pay the deposit, the woman replies "I'll pay by credit card."

10. email - The receptionist says "we'll send you a confirmation by email with all the details."

### Section 2: Community Center Renovation Project

11. 1985 - The speaker mentions "our center was originally built in 1985."

12. six months - The speaker states "The center will be closed for renovation for a period of six months."

13. sound system - The speaker explains "In the main hall, we'll be installing a new sound system."

14. 200 - The speaker mentions they will be "expanding the main hall to increase its capacity from the current 120 to 200 people."

15. commercial appliances - The speaker states "The kitchen will be completely modernized with new commercial appliances."

16. parking lot - The speaker says "On the east side of the building, we'll be building a new parking lot."

17. the city council - The speaker explains "the project is mainly funded by the city council."

18. £50,000 - The speaker mentions local businesses "have collectively donated £50,000 toward the renovation."

19. landscaping - The speaker states "we'll need volunteers to help with landscaping the grounds around the center."

20. Janet Williams - The speaker advises "please contact Janet Williams, our volunteer coordinator."

### Section 3: Student Discussion about Research Project

21. B - The female student confirms the focus on coastal erosion when she says "I think your idea to focus our project on coastal erosion is good."

22. A - The female student expresses concern that their data is "too limited in scope" and explains they "only have information from two coastal areas."

23. B - The male student suggests "What if we collect our own data? We cou
(Content truncated due to size limit. Use line ranges to read in chunks)