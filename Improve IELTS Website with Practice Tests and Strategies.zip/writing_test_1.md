# Sample IELTS Writing Practice Test 1 (Band 7-7.5)

## TASK 1 (Academic)

You should spend about 20 minutes on this task.

The graph below shows the percentage of people living in urban areas in different parts of the world between 1950 and 2050 (projected).

Summarize the information by selecting and reporting the main features, and make comparisons where relevant.

Write at least 150 words.

[Note: The graph would show urbanization trends across different regions (North America, Europe, Asia, Africa, etc.) from 1950-2050, with projected data after 2020]

## TASK 2

You should spend about 40 minutes on this task.

Write about the following topic:

Some people believe that universities should focus on providing academic skills, while others think that preparing students for employment is more important.

Discuss both these views and give your own opinion.

Give reasons for your answer and include any relevant examples from your own knowledge or experience.

Write at least 250 words.

## MODEL ANSWER - TASK 1

The line graph illustrates the percentage of the population living in urban areas across different regions of the world from 1950 to 2020, with projections extending to 2050.

Overall, there has been a clear upward trend in urbanization across all regions, though at varying rates and from different starting points. North America and Europe have consistently maintained the highest levels of urbanization, while Africa has remained the least urbanized region despite significant growth.

In 1950, North America already had approximately 65% of its population living in urban areas, followed by Europe at around 50%. By contrast, only about 15% of Africa's population and 20% of Asia's population resided in cities at that time. Latin America showed moderate urbanization at roughly 40%.

Between 1950 and 2020, all regions experienced substantial increases in urban population percentages. Latin America demonstrated the most dramatic rise, surpassing Europe by 2000 to become the second most urbanized region at approximately 80%. Asia's urban population grew steadily to reach about 50% by 2020, while Africa's urbanization, though remaining the lowest, more than doubled to approximately 40%.

The projections to 2050 indicate continued urbanization across all regions, with North America and Latin America expected to reach around 90%, Europe approaching 85%, Asia exceeding 65%, and Africa reaching approximately 55% urban population.

(178 words)

## MODEL ANSWER - TASK 2

The debate over whether universities should prioritize academic knowledge or employment preparation reflects the evolving purpose of higher education in contemporary society. While both perspectives have merit, I believe a balanced approach that integrates theoretical knowledge with practical skills offers the most value to students.

Proponents of academically-focused education argue that universities should remain bastions of intellectual development and theoretical understanding. They contend that the primary purpose of higher education is to cultivate critical thinking, research capabilities, and comprehensive knowledge of specific disciplines. This traditional view emphasizes that universities should not be reduced to vocational training centers but should instead foster intellectual curiosity and academic rigor. Furthermore, a strong theoretical foundation often provides graduates with the adaptability to navigate changing career landscapes throughout their lives, rather than preparing them for specific jobs that may become obsolete.

Conversely, those advocating for employment-oriented education highlight the practical realities facing graduates. With rising tuition costs and competitive job markets, students increasingly view university education as an investment that should yield tangible career outcomes. Supporters of this perspective argue that universities have a responsibility to ensure graduates possess the practical skills, technological proficiency, and professional competencies demanded by employers. They point to the frustration of graduates who discover a significant gap between their academic knowledge and workplace requirements.

In my view, this dichotomy presents a false choice. The most effective university education integrates academic rigor with practical application. For instance, medical schools combine theoretical understanding of human physiology with clinical practice, producing graduates who are both knowledgeable and capable. Similarly, engineering programs that incorporate industry partnerships and practical projects alongside theoretical coursework prepare students more comprehensively for professional challenges.

Universities can achieve this balance through various approaches, such as incorporating internships into degree requirements, involving industry professionals in curriculum development, and designing assessments that evaluate both theoretical understanding and practical application. Additionally, interdisciplinary programs that break down traditional academic silos often better reflect the complex, multifaceted nature of real-world problems.

In conclusion, while the tension between academic focus and employment preparation is real, universities serve students best when they integrate both elements. By fostering both intellectual development and practical capabilities, higher education can prepare graduates not just for their first job, but for lifelong career success and meaningful contributions to society.

(367 words)

## DETAILED ANALYSIS

### Task 1 Analysis

#### Task Achievement (Band 7-8)
- The response clearly presents an overview of the main trends
- All key features of the graph are covered (different regions, time periods, comparative trends)
- Data is accurately reported with appropriate detail
- Comparisons are made effectively between regions and time periods
- The response is well-developed within the word limit

#### Coherence and Cohesion (Band 7)
- Information is logically organized with a clear progression
- Paragraphing is appropriate with each paragraph focusing on a specific aspect
- Cohesive devices are used effectively but not overused
- The overview is clearly identifiable
- The response reads as a cohesive whole

#### Lexical Resource (Band 7-8)
- Uses a good range of vocabulary related to demographic trends
- Employs precise vocabulary for describing trends: "upward trend," "dramatic rise," "surpassing"
- Shows good awareness of collocation: "substantial increases," "moderate urbanization"
- Avoids repetition through varied vocabulary
- Few errors in word choice or formation

#### Grammatical Range and Accuracy (Band 7)
- Uses a mix of simple and complex sentence structures
- Employs a variety of grammatical structures
- Demonstrates good control of grammar and punctuation
- Uses appropriate tenses to describe past trends and future projections
- Contains only minor errors that do not impede communication

### Task 2 Analysis

#### Task Achievement (Band 7-8)
- Addresses all parts of the task with a clear position
- Presents a fully developed response with relevant, extended arguments
- Supports ideas with relevant examples
- Presents a clear conclusion that aligns with the position stated
- Shows a nuanced understanding of the issue

#### Coherence and Cohesion (Band 7-8)
- Logically organizes information and ideas with clear progression
- Uses paragraphing effectively to separate and develop ideas
- Uses a range of cohesive devices appropriately
- Manages all aspects of cohesion well
- Each paragraph has a clear central topic

#### Lexical Resource (Band 7-8)
- Uses a wide range of vocabulary with flexibility and precision
- Uses less common vocabulary items naturally: "bastions," "dichotomy," "interdisciplinary"
- Shows awareness of style and collocation: "academic rigor," "tangible career outcomes"
- Makes only occasional errors in word choice
- Demonstrates good awareness of academic vocabulary

#### Grammatical Range and Accuracy (Band 7)
- Uses a variety of complex structures
- Produces frequent error-free sentences
- Has good control of grammar and punctuation
- Makes only occasional errors in grammar and punctuation
- Uses appropriate tenses throughout

## WRITING STRATEGIES

### Task 1 Strategies
- Begin with a clear introduction that paraphrases the question
- Include an overview paragraph identifying the main trends
- Organize body paragraphs logically (by time periods or by regions)
- Use appropriate language to describe trends (increase, decrease, fluctuate, etc.)
- Make meaningful comparisons between data points
- Be selective about which data to include; focus on significant patterns
- Use precise figures but avoid listing every number from the graph
- Aim for 170-190 words to ensure adequate development

### Task 2 Strategies
- Analyze the question carefully to identify all parts that need addressing
- Plan your essay structure before writing
- Present a clear position in your introduction
- Develop each paragraph around a single main idea
- Support arguments with specific examples and explanations
- Use a range of linking words to connect ideas
- Write a conclusion that summarizes your main points and restates your position
- Aim for 280-320 words to ensure adequate development
- Allow time to review your essay for errors

## VOCABULARY AND PHRASES

### Task 1 Vocabulary
- Trends: upward trend, dramatic rise, steady increase, gradual decline, fluctuation
- Comparisons: significantly higher, marginally lower, comparable to, in contrast to
- Time expressions: over the period, throughout the decades, by the end of, projected to
- Data description: approximately, precisely, roughly, nearly, just over/under
- Superlatives: the highest, the most dramatic, the least urbanized

### Task 2 Vocabulary
- Academic discussion: perspective, contend, argue, highlight, emphasize
- Opinion expressions: in my view, I believe, it seems clear that
- Concession: while, although, despite, nevertheless, however
- Emphasis: particularly, significantly, notably, crucially
- Conclusion: in conclusion, to summarize, ultimately, in sum
