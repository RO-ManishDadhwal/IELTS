import React from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from './ui/card';

interface SectionProps {
  title: string;
  description: string;
  icon: React.ReactNode;
  color: string;
  url: string;
}

const Section: React.FC<SectionProps> = ({ title, description, icon, color, url }) => {
  return (
    <Card className={`border-l-4 ${color} hover:shadow-md transition-shadow`}>
      <CardHeader className="pb-2">
        <div className="flex items-center gap-3">
          <div className={`p-2 rounded-full ${color.replace('border', 'bg').replace('-700', '-100')} ${color.replace('border', 'text')}`}>
            {icon}
          </div>
          <CardTitle>{title}</CardTitle>
        </div>
      </CardHeader>
      <CardContent>
        <CardDescription className="text-base">{description}</CardDescription>
      </CardContent>
      <CardFooter>
        <Button variant="outline" className={`${color.replace('border', 'text')} hover:${color.replace('border', 'bg').replace('-700', '-50')}`} asChild>
          <a href={url}>Explore {title}</a>
        </Button>
      </CardFooter>
    </Card>
  );
};

export default Section;
