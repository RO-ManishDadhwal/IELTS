# IELTS Speaking Practice Tests Structure

## Overview
This document outlines the structure for 50 Cambridge-style IELTS Speaking practice tests at Band 7 level. Each test will follow the official IELTS Speaking test format and include model answers with detailed analysis.

## Test Format
- **3 Parts**: Introduction and interview, individual long turn, two-way discussion
- **Total Time**: 11-14 minutes
- **Conducted by**: Examiner (simulated in practice materials)
- **Assessment Criteria**: Fluency and coherence, Lexical resource, Grammatical range and accuracy, Pronunciation

## Structure for Each Practice Test
1. **Test Introduction**
   - Test number and source reference
   - Instructions and format explanation
   - Target band score indication (7)

2. **Part 1: Introduction and Interview (4-5 minutes)**
   - General questions about familiar topics
   - 3-4 topic areas with 3-4 questions each
   - Sample examiner questions and follow-ups

3. **Part 2: Individual Long Turn (3-4 minutes)**
   - Task card with topic and points to include
   - 1-minute preparation time (notes allowed)
   - 2-minute speaking time
   - 1-2 follow-up questions

4. **Part 3: Two-way Discussion (4-5 minutes)**
   - Abstract questions related to Part 2 topic
   - 5-7 examiner questions with increasing complexity
   - Discussion format with follow-up questions

5. **Model Answers**
   - Band 7 sample responses for all parts
   - Natural speech patterns with appropriate hesitations
   - Range of vocabulary and grammatical structures

6. **Detailed Analysis**
   - Fluency and coherence analysis
   - Lexical resource analysis
   - Grammatical range and accuracy analysis
   - Pronunciation analysis
   - Examiner comments and feedback
   - Band score justification

7. **Speaking Strategies**
   - Part-specific approach strategies
   - Techniques for extending answers
   - Methods for dealing with unfamiliar topics
   - Strategies for demonstrating language range
   - Common pitfalls to avoid

8. **Vocabulary and Phrases**
   - Topic-specific vocabulary
   - Useful phrases and expressions
   - Advanced grammatical structures
   - Discourse markers and linking devices

## Sample Test Structure
```
SPEAKING TEST 1 (Band 7)

PART 1: INTRODUCTION AND INTERVIEW
[Topic 1: Work/Studies]
- What do you do? (work/study)
- Why did you choose this job/course?
- Do you enjoy your work/studies?
- Would you like to change your job/course in the future?

[Topic 2: Hometown]
- Where is your hometown?
- What is it known for?
- Has it changed much since you were a child?
- Do you think it's a good place to raise children?

[Topic 3: Free time]
- What do you enjoy doing in your free time?
- How often do you do this?
- Who do you usually do this with?
- Have your hobbies changed since you were a child?

PART 2: INDIVIDUAL LONG TURN
[Task card]
Describe a skill you would like to learn.
You should say:
- what the skill is
- why you want to learn it
- how you would learn it
- and explain how this skill would be useful to you in the future.

[1-minute preparation time]
[2-minute speaking time]

Follow-up question:
- Would this skill be difficult to learn?

PART 3: TWO-WAY DISCUSSION
[Questions related to skills and learning]
- What kinds of skills are most valued in today's society?
- Do you think the skills people need today are different from those needed in the past?
- How has technology changed the way people learn new skills?
- Do you think schools should focus more on practical skills or academic knowledge?
- How important is it for people to continue learning new skills throughout their lives?
- What role should employers play in developing their employees' skills?

MODEL ANSWERS
[Band 7 sample responses for all parts]

DETAILED ANALYSIS
[Comprehensive analysis of performance]

SPEAKING STRATEGIES
[Specific strategies for this test]

VOCABULARY AND PHRASES
[Useful language for this test]
```

## Implementation Notes
- Each test will be saved as a separate markdown file
- Tests will be numbered from 1 to 50
- All tests will maintain consistent formatting
- Tests will cover a wide range of topics to ensure comprehensive preparation
- Model answers will demonstrate Band 7 level speaking
- Analysis will focus on how to achieve the target band score
- Audio recordings of model answers will be provided where possible
