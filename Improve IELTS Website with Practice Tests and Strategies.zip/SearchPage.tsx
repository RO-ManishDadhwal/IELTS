import React, { useState, useEffect } from 'react';
import { searchIeltsContent } from '../lib/searchUtils';
import SearchBar from './SearchBar';
import SearchResults, { SearchResult } from './SearchResults';

const SearchPage: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [results, setResults] = useState<SearchResult[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [hasSearched, setHasSearched] = useState(false);

  const handleSearch = async (query: string) => {
    setSearchQuery(query);
    setIsLoading(true);
    setHasSearched(true);
    
    try {
      // In a real implementation, this would call an API
      const searchResults = await searchIeltsContent(query);
      setResults(searchResults);
    } catch (error) {
      console.error('Search error:', error);
      setResults([]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col items-center mb-8">
        <h1 className="text-3xl font-bold text-center mb-6">IELTS Resource Search</h1>
        <p className="text-gray-600 text-center mb-6 max-w-2xl">
          Search for practice tests, strategy guides, grammar rules, and examples across all IELTS sections.
        </p>
        <SearchBar onSearch={handleSearch} />
      </div>

      {hasSearched && (
        <div className="mt-4">
          <h2 className="text-xl font-semibold mb-4">
            {isLoading 
              ? 'Searching...' 
              : results.length > 0 
                ? `Search results for "${searchQuery}"` 
                : `No results found for "${searchQuery}"`
            }
          </h2>
          <SearchResults results={results} isLoading={isLoading} />
        </div>
      )}

      {!hasSearched && (
        <div className="mt-12 text-center">
          <h2 className="text-xl font-semibold mb-4">Popular Search Categories</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mt-6">
            {['Reading', 'Writing', 'Listening', 'Speaking'].map((section) => (
              <div 
                key={section}
                className="bg-white rounded-lg shadow-md p-6 cursor-pointer hover:shadow-lg transition-shadow"
                onClick={() => handleSearch(section.toLowerCase())}
              >
                <h3 className="font-bold text-lg mb-2">{section}</h3>
                <p className="text-gray-600">
                  Find practice tests, strategies, and examples for {section.toLowerCase()}.
                </p>
              </div>
            ))}
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-8">
            {[
              { title: 'Grammar Rules', query: 'grammar rules' },
              { title: 'Band 7+ Strategies', query: 'band 7 strategies' },
              { title: 'Common Mistakes', query: 'common mistakes' }
            ].map((item) => (
              <div 
                key={item.title}
                className="bg-white rounded-lg shadow-md p-6 cursor-pointer hover:shadow-lg transition-shadow"
                onClick={() => handleSearch(item.query)}
              >
                <h3 className="font-bold text-lg mb-2">{item.title}</h3>
                <p className="text-gray-600">
                  Explore resources related to {item.title.toLowerCase()}.
                </p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default SearchPage;
